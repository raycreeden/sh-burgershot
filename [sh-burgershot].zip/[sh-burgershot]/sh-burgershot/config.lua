Config = {}

-- Job requerido
Config.JobName = "burgershot"

-- Prop de iniciar/salir servicio
Config.DutyProp = {
    model = "vw_prop_casino_schedule_01a",
    coords = vector3(-1187.94, -897.07, 14.46),
    rotation = vector3(90.0, 155.0, 150.0) -- X, Y, Z
}

-- Stash
Config.Stash = {
    coords = vector3(-1203.49, -896.22, 14.38),
    stashName = "stash_burgershot",
    label = "Almacén Burgershot",
    maxweight = 9750000,
    slots = 70
}

-- Puntos de facturación
Config.Facturas = {
    vector3(-1197.42, -892.58, 14.08),
    vector3(-1195.4, -893.08, 14.07),
    vector3(-1193.41, -893.62, 14.07),
    vector3(-1191.48, -894.15, 14.06)
}

-- ==========================
-- PEDIDOS Y PRODUCCIÓN
-- ==========================

-- Punto para iniciar pedidos (qb-target)
Config.Pedidos = {
    coords = vector3(-1194.68, -901.35, 14.29),
    cantidades = { 25, 50, 75, 100 },
    items = {
        carne_cruda = { precio = 8 },  --Carne Cruda
        hielo_sh = { precio = 3 }, -- Hielos
        lechuga_sh = { precio = 4 }, --Lechuga
        papa_sh = { precio = 3 }, -- Papa
        tomate_sh = { precio = 4 }, --Tomate
        agua_burger = { precio = 2 }, --AguaShot
        burger_cafe = { precio = 5 }, --CafeShot
        sh_frutilla = { precio = 6 }, --Frutillas          
        sh_limon = { precio = 5 }     --Limones            
    }
}

-- Producción - puntos de trabajo
Config.Produccion = {
    Exprimidos = {
        coords = vector3(-1199.8, -896.28, 14.23),
        requiredJob = true,
        recipes = {
            expr_frutilla = { sh_frutilla = 1, hielo_sh = 1 },
            expr_limon = { sh_limon = 1, hielo_sh = 1 }
        },
        cantidades = {1, 3, 5, 10}
    },
    CortarPapas = {
        prop = "v_res_mchopboard",
        coords = vector3(-1197.79, -899.58, 13.8),
        requiredJob = true,
        input = "papa_sh",
        output = "papa_cortada",
        cantidades = {1, 3, 5, 10}
    },
    FreirPapas = {
        coords = vector3(-1195.86, -899.81, 13.8),
        requiredJob = true,
        input = "papa_cortada",
        output = "papas_fr",
        cantidades = {1, 3, 5, 10}
    },
    CortarTomate = {
    prop = "v_res_mchopboard",
    coords = vector3(-1194.17, -900.39, 13.8),
    requiredJob = true,
    input = "tomate_sh",
    output = "tomate_cort",
    cantidades = {1, 3, 5, 10}
},

CortarLechuga = {
    prop = "v_res_mchopboard",
    coords = vector3(-1193.45, -900.55, 13.85),
    requiredJob = true,
    input = "lechuga_sh",
    output = "hojas_lech",
    cantidades = {1, 3, 5, 10}
},
ComprarRefresco = {
    coords = vector3(-1191.03, -898.74, 14.29),
    requiredJob = true,
    input = "hielo_sh",
    output = "refresco_bur",
    cantidades = {1, 3, 5, 10}
},

    FreirHamburguesa = {
        coords = vector3(-1195.15, -897.2, 13.91),
        requiredJob = true,
        input = "carne_cruda",
        output = "carne_cocida",
        cantidades = {1, 3, 5, 10}
    },
    HamburguesaCompleta = {
    coords = vector3(-1194.61, -897.95, 13.82),
    requiredJob = true,
    input1 = "carne_cocida",
    input2 = "tomate_cort",
    input3 = "hojas_lech",
    output = "hamb_vale",
    cantidades = {1, 3, 5, 10}
},
    HamburguesaSimple = {
        coords = vector3(-1195.9, -897.57, 13.82),
        requiredJob = true,
        input = "carne_cocida",
        output = "hamb_vale",
        cantidades = {1, 3, 5, 10}
    },
    RetirarHamburguesa = {
        coords = vector3(-1194.07, -896.48, 14.14),
        requiredJob = true,
        options = {
            { label = "Hamburguesa Doble Completa", item = "hamb_doblecomp" },
            { label = "Hamburguesa Simple", item = "hamb_simple" }
        },
        requiere = "hamb_vale",
        cantidades = {1, 3, 5, 10}
    }
}

-- ==========================
-- DELIVERY
-- ==========================

Config.Delivery = {
    vehiculo = "mule3",
    inicio = vector4(-1205.77, -901.2, 13.63, 35.81), -- Siempre el mismo inicio
    fin = vector4(-1171.96, -888.98, 14.19, 215.1),   -- Siempre el mismo fin

    rutas = {
        {
            porcentaje = 25,
            posAcomodar = vector3(2673.3, 3459.27, 55.71),
            spawnCamion = vector4(2673.8, 3459.26, 55.95, 159.22),
            posCaja = vector3(2676.55, 3466.51, 55.6),
            posDentroCamion = vector3(2674.33, 3461.76, 55.85)
        },
        {
            porcentaje = 20,
            posAcomodar = vector3(-1087.13, -2046.79, 13.22),
            spawnCamion = vector4(-1087.56, -2047.81, 13.46, 311.94),
            posCaja = vector3(-1095.29, -2054.2, 13.29),
            posDentroCamion = vector3(-1087.99, -2048.26, 13.38)
        },
        {
            porcentaje = 20,
            posAcomodar = vector3(-229.94, -2647.41, 6.0),
            spawnCamion = vector4(-229.45, -2650.02, 6.24, 1.14),
            posCaja = vector3(-229.61, -2658.42, 6.0),
            posDentroCamion = vector3(-229.59, -2650.53, 6.14)
        },
        {
            porcentaje = 20,
            posAcomodar = vector3(906.87, -1739.68, 30.51),
            spawnCamion = vector4(906.91, -1734.44, 30.8, 175.27),
            posCaja = vector3(907.8, -1727.17, 32.16),
            posDentroCamion = vector3(906.87, -1734.31, 30.71)
        },
        {
            porcentaje = 15,
            posAcomodar = vector3(197.19, 6384.22, 31.39),
            spawnCamion = vector4(195.98, 6383.53, 31.63, 298.99),
            posCaja = vector3(189.02, 6378.13, 32.33),
            posDentroCamion = vector3(195.47, 6383.05, 31.54)
        }
    }
}

----------------------
---Consumibles--------
----------------------

Config.Consumables = {
    ['hamb_simple'] = {
        progress = { label = 'Comiendo Hamburguesa...', time = 4000 },
        animation = { animDict = 'mp_player_inteat@burger', anim = 'mp_player_int_eat_burger', flags = 49 },
        prop = { model = 'prop_cs_burger_01', bone = 60309, coords = vec3(0.0, 0.0, 0.02), rotation = vec3(0.0, 0.0, 0.0) },
        replenish = { type = 'Hunger', replenish = 50 }
    },
    ['hamb_doblecomp'] = {
        progress = { label = 'Comiendo Doble Completa...', time = 4000 },
        animation = { animDict = 'mp_player_inteat@burger', anim = 'mp_player_int_eat_burger', flags = 49 },
        prop = { model = 'prop_cs_burger_01', bone = 60309, coords = vec3(0.0, 0.0, 0.02), rotation = vec3(0.0, 0.0, 0.0) },
        replenish = { type = 'Hunger', replenish = 65 }
    },
    ['expr_limon'] = {
        progress = { label = 'Bebiendo Limonada...', time = 4000 },
        animation = { animDict = 'mp_player_intdrink', anim = 'loop_bottle', flags = 49 },
        prop = { model = 'p_w_grass_gls_s', bone = 60309, coords = vec3(0.0, 0.0, 0.05), rotation = vec3(0.0, 0.0, 0.0) },
        replenish = { type = 'Thirst', replenish = 35 }
    },
    ['expr_frutilla'] = {
        progress = { label = 'Bebiendo Frutilla...', time = 4000 },
        animation = { animDict = 'mp_player_intdrink', anim = 'loop_bottle', flags = 49 },
        prop = { model = 'sf_p_sf_grass_gls_s_02a', bone = 60309, coords = vec3(0.0, 0.0, 0.05), rotation = vec3(0.0, 0.0, 0.0) },
        replenish = { type = 'Thirst', replenish = 35 }
    },
    ['refresco_bur'] = {
        progress = { label = 'Bebiendo Refresco...', time = 4000 },
        animation = { animDict = 'mp_player_intdrink', anim = 'loop_bottle', flags = 49 },
        prop = { model = 'prop_cs_bs_cup', bone = 60309, coords = vec3(0.0, 0.0, 0.05), rotation = vec3(0.0, 0.0, 0.0) },
        replenish = { type = 'Thirst', replenish = 35 }
    },
    ['agua_burger'] = {
        progress = { label = 'Bebiendo Agua...', time = 4000 },
        animation = { animDict = 'mp_player_intdrink', anim = 'loop_bottle', flags = 49 },
        prop = { model = 'prop_cs_paper_cup', bone = 60309, coords = vec3(0.0, 0.0, 0.05), rotation = vec3(0.0, 0.0, 0.0) },
        replenish = { type = 'Thirst', replenish = 35 }
    },
    ['papas_fr'] = {
    progress = { label = 'Comiendo Papas Fritas...', time = 4000 },
    animation = { animDict = 'mp_player_inteat@burger', anim = 'mp_player_int_eat_burger', flags = 49 },
    prop = { model = 'prop_food_bs_chips', bone = 60309, coords = vec3(0.0, 0.0, 0.02), rotation = vec3(0.0, 0.0, 0.0) },
    replenish = { type = 'Hunger', replenish = 30 }
    },

    ['burger_cafe'] = {
        progress = { label = 'Tomando Café...', time = 4000 },
        animation = { animDict = 'mp_player_intdrink', anim = 'loop_bottle', flags = 49 },
        prop = { model = 'prop_food_bs_coffee', bone = 60309, coords = vec3(0.03, 0.01, 0.04), rotation = vec3(0.0, 0.0, 0.0) },
        replenish = { type = 'Thirst', replenish = 25 }
    }
}

-- Ubicaciones de dispensadores de AguaShot (accesibles a todos)
Config.AguaShotDispensers = {
    vector3(-1188.69, -894.79, 13.97),
    vector3(-1203.55, -891.53, 13.89)
}

-- Precio por unidad
Config.AguaShotPrice = 55

-- Nueva entrada en Config.Produccion para la cafetera
Config.CafeteraEspresso = {
    prop = "sf_prop_sf_esp_machine_01a",
    coords = vector3(-1197.94, -892.4, 13.98),
    heading = 165.0,
    cantidades = {1, 3, 5, 10},
    item = "burger_cafe",
    label = "CafeShot",
    precio = 80
}

-- ================================
-- Boss Menu Props
-- ================================
Config.BossMenuProps = {
    atril = {
        model = "prop_lectern_01",
        coords = vector3(-1200.83, -901.32, 12.89),
        heading = 35.0
    },
    notebook = {
        model = "as_prop_as_laptop_01a",
        coords = vector3(-1200.86, -901.28, 14.0),
        rotation = vector3(20.0, 0.0, 34.0) -- X, Y, Z  ← aquí modificas la inclinación
    }
}
-- Boss Menu Burgershot
Config.BossMenu = {
    coords = vector3(-1200.89, -901.29, 14.06),
    job = "burgershot",
    minGrade = 0 -- mínimo grado para abrir el menú
}
Config.SecurityCameras = {
    cameras = {
        [1] = {
            label = "📦 Depósito",
            coords = vector3(-1199.06, -903.65, 16.75),
            r = vector3(-30.0, 0.0, 30.0),
            canRotate = true,
            isOnline = true
        },
        [2] = {
            label = "👨‍🍳 Centro de Trabajo",
            coords = vector3(-1202.27, -899.88, 16.56),
            r = vector3(-25.0, 0.0, -30.0),
            canRotate = true,
            isOnline = true
        },
        [3] = {
            label = "🛎️ Mostrador",
            coords = vector3(-1186.12, -897.84, 16.26),
            r = vector3(-15.0, 0.0, -50.0),
            canRotate = true,
            isOnline = true
        },
        [4] = {
            label = "🚪 Entrada",
            coords = vector3(-1176.99, -890.65, 17.22),
            r = vector3(-15.0, 0.0, 0.0),
            canRotate = true,
            isOnline = true
        },
        [5] = {
            label = "📑 Zona de Pedidos",
            coords = vector3(-1203.25, -910.40, 14.39),
            r = vector3(-15.0, 0.0, -15.0),
            canRotate = true,
            isOnline = true
        }
    }
}

-- Botón de Pánico (Burgershot)
Config.PanicButton = {
    coords = vector3(-1189.09, -895.36, 14.44), -- ubicación que me diste
    rot = { x = 0.0, y = 0.0, z = 305.0 }, -- rotación inicial (puedes ajustar)
    job = "burgershot",
    label = "Botón de Pánico (Burgershot)"
}

-- NPC para Spawn/Guardar vehículo de empresa
Config.CompanyVehiclePed = {
    coords = vector4(-1177.45, -904.45, 12.58, 32.37),
    job = "burgershot",
    model = `a_m_y_gencaspat_01`,
    vehicleSpawn = vector4(-1175.32, -900.47, 12.22, 301.58),
    vehicleModel = `novak`
}
-- 📦 Configuración de guardarropa Burgershot
Config.WardrobeProp = {
    model = "prop_big_bag_01",
    coords = vector3(-1198.32, -901.57, 12.89),
    heading = 130.0, -- Puedes ajustarlo si quieres rotar el mueble
}

-- =============================
--  Configuración de Ropa BurgerShot
-- =============================
Config.RopaTrabajo = { 
    male = { 
        ['accessory'] = { component = 7, drawable = 0, texture = 0 },
        ['hat'] = { prop = 0, drawable = 131, texture = 2 },
        ['torso2'] = { component = 11, drawable = 281, texture = 1 },
        ['t-shirt'] = { component = 8, drawable = 15, texture = 0 },
        ['arms'] = { component = 3, drawable = 30, texture = 0 },
        ['pants'] = { component = 4, drawable = 144, texture = 19 },
        ['shoes'] = { component = 6, drawable = 1, texture = 10 },
        ['bag'] = { component = 5, drawable = 0, texture = 0 },
        ['decals'] = { component = 10, drawable = 0, texture = 0 },
        ['torso'] = { component = 9, drawable = 0, texture = 0 },
        ['mask'] = { component = 1, drawable = 0, texture = 0 },
        ['vest'] = { component = 9, drawable = 0, texture = 0 }
    },
    female = { 
        ['accessory'] = { component = 7, drawable = 0, texture = 0 },
        ['hat'] = { prop = 0, drawable = 129, texture = 2 },
        ['torso2'] = { component = 11, drawable = 245, texture = 7 },
        ['t-shirt'] = { component = 8, drawable = 15, texture = 0 },
        ['arms'] = { component = 3, drawable = 44, texture = 0 },
        ['pants'] = { component = 4, drawable = 27, texture = 2 },
        ['shoes'] = { component = 6, drawable = 1, texture = 4 },
        ['bag'] = { component = 5, drawable = 0, texture = 0 },
        ['decals'] = { component = 10, drawable = 0, texture = 0 },
        ['torso'] = { component = 9, drawable = 0, texture = 0 },
        ['mask'] = { component = 1, drawable = -1, texture = 0 },
        ['vest'] = { component = 9, drawable = 0, texture = 0 }
    }
}

Config.RopaTrabajo2 = {
    male = { 
        ['accessory'] = { component = 7, drawable = 0, texture = 0 },
        ['hat'] = { prop = 0, drawable = 131, texture = 2 },
        ['torso2'] = { component = 11, drawable = 235, texture = 7 },
        ['t-shirt'] = { component = 8, drawable = 15, texture = 0 },
        ['arms'] = { component = 3, drawable = 30, texture = 0 },
        ['pants'] = { component = 4, drawable = 144, texture = 10 },
        ['shoes'] = { component = 6, drawable = 1, texture = 10 },
        ['bag'] = { component = 5, drawable = 0, texture = 0 },
        ['decals'] = { component = 10, drawable = 0, texture = 0 },
        ['torso'] = { component = 9, drawable = 0, texture = 0 },
        ['mask'] = { component = 1, drawable = 0, texture = 0 },
        ['vest'] = { component = 9, drawable = 0, texture = 0 }
    },
    female = { 
        ['accessory'] = { component = 7, drawable = 0, texture = 0 },
        ['hat'] = { prop = 0, drawable = 45, texture = 0 },
        ['torso2'] = { component = 11, drawable = 250, texture = 5 },
        ['t-shirt'] = { component = 8, drawable = 15, texture = 0 },
        ['arms'] = { component = 3, drawable = 31, texture = 0 },
        ['pants'] = { component = 4, drawable = 90, texture = 2 },
        ['shoes'] = { component = 6, drawable = 10, texture = 0 },
        ['bag'] = { component = 5, drawable = 0, texture = 0 },
        ['decals'] = { component = 10, drawable = 0, texture = 0 },
        ['torso'] = { component = 9, drawable = 0, texture = 0 },
        ['mask'] = { component = 1, drawable = 0, texture = 0 },
        ['vest'] = { component = 9, drawable = 0, texture = 0 }
    }
}

Config = Config or {}

-- Puntos donde se puede ver el menú de Burgershot
Config.BurgershotMenuLocations = {
    vector3(-1189.35, -887.13, 14.41),
    vector3(-1186.51, -885.22, 14.42),
    vector3(-1182.29, -891.55, 14.45),
    vector3(-1185.07, -893.42, 14.42)
}

-- Ítems del menú visual (solo para mostrar)
Config.BurgershotItems = {
    { name = 'expr_frutilla', label = 'Exprimido Frutilla' },
    { name = 'expr_limon', label = 'Exprimido Limon' },
    { name = 'hamb_doblecomp', label = 'Hamburguesa Doble Completa' },
    { name = 'hamb_simple', label = 'Hamburguesa Simple' },
    { name = 'papas_fr', label = 'Papas Fritas' },
    { name = 'burger_cafe', label = 'CafeShot' },
    { name = 'agua_burger', label = 'AguaShot' },
    { name = 'refresco_bur', label = 'Refresco Burger' }
}

-- Stashes temporales para entregar pedidos
Config.StashTemporales = {
    { coords = vector3(-1196.68, -892.88, 14.0), name = "burgershot_temp_1" },
    { coords = vector3(-1195.0,  -893.35, 14.0), name = "burgershot_temp_2" },
    { coords = vector3(-1192.82, -893.84, 14.0), name = "burgershot_temp_3" },
    { coords = vector3(-1191.03, -894.39, 14.0), name = "burgershot_temp_4" }
}

-- Prop de limpieza (balde y trapeador)
Config.PropLimpieza = {
    model = "m23_2_prop_m32_bucket_mop_01b",
    coords = vector3(-1201.44, -900.62, 12.89),
    heading = 0.0
}

-- 🧹 Configuración de limpieza Burgershot
Config.LimpiezaBurger = {
    inicio = vector3(-1201.4, -900.44, 13.17), -- 📍 Punto para iniciar limpieza
    cooldown = 20 * 60, -- segundos (20 minutos)
    pagoTotal = 300, -- pago total por limpiar todas las zonas
    propMopa = "prop_cs_mop_s",

        marker = {
        type = 2,              -- Marker 2
        size = vector3(0.2, 0.2, 0.2), -- Tamaño
        color = {r = 0, g = 0, b = 0, a = 50}, -- Color negro con transparencia
        offsetZ = 1.8,
    },
    -- Props de manchas
    propsSuciedad = {
    {model = "ng_proc_food_burg02c", chance = 70}, -- 70% probabilidad
    {model = "prop_bird_poo", chance = 50},
    {model = "ng_proc_paper_03a", chance = 60},
    {model = "v_ret_fh_bsbag", chance = 40},
    {model = "ng_proc_food_bag02a", chance = 50},
    {model = "ng_proc_paper_burger01a", chance = 50},
    {model = "xs_propint3_waste_02_garbage_c", chance = 60},
},

    zonas = {
        vector3(-1199.24, -901.95, 12.89),
        vector3(-1202.31, -899.31, 12.89),
        vector3(-1196.53, -901.55, 12.89),
        vector3(-1202.84, -895.83, 12.89),
        vector3(-1199.71, -897.83, 12.89),
        vector3(-1195.49, -898.95, 12.89),
        vector3(-1191.76, -897.9, 12.89),
        vector3(-1199.65, -893.64, 12.89),
        vector3(-1194.24, -895.25, 12.89),
        vector3(-1178.67, -892.93, 12.89),
        vector3(-1184.16, -896.49, 12.89),
        vector3(-1187.48, -894.99, 12.89),
        vector3(-1182.58, -887.02, 12.89),
        vector3(-1186.92, -889.38, 12.89),
        vector3(-1187.21, -881.87, 12.89),
        vector3(-1192.06, -885.18, 12.89),
        vector3(-1192.98, -892.39, 12.89),
        vector3(-1200.73, -888.84, 12.89),
        vector3(-1205.76, -891.86, 12.89),
        vector3(-1201.89, -892.46, 12.89),
        vector3(-1203.69, -893.54, 12.89)
    }
}
-- 📌 Props especiales Burgershot
Config.PropsEspeciales = {
    {
        model = "prop_fib_clipboard",
        coords = vector3(-1192.24, -900.6, 15.3),
        rotation = vector3(0.0, 0.0, 215.0) -- Rotación X, Y, Z
    }
}

-- 📍 Zona del qb-target para Recetas
Config.RecetasMenu = {
    coords = vector3(-1192.25, -900.6, 14.41),
    job = "burgershot",
    minGrade = 0 -- mínimo rango para ver las recetas
}

-- 📖 Recetas visuales (solo información)
Config.RecetasBurgershot = {
    {
        nombre = "🥤 Exprimido de Frutilla x1",
        ingredientes = {
            "1 Frutilla",
            "1 Hielo"
        }
    },
    {
        nombre = "🥤 Exprimido de Limón x1",
        ingredientes = {
            "1 Limón",
            "1 Hielo"
        }
    },
    {
        nombre = "🍟 Papas Fritas x1",
        ingredientes = {
            "1 Papa Cortada"
        }
    },
    {
        nombre = "🍔 Hamburguesa Simple x1",
        ingredientes = {
            "1 Carne Cruda"
        }
    },
    {
        nombre = "🍔🍔 Hamburguesa Doble Completa x1",
        ingredientes = {
            "1 Tomate Cortado",
            "1 Hoja de Lechuga",
            "1 Carne Cruda"
        }
    },
    {
        nombre = "🥤 Refresco x1",
        ingredientes = {
            "1 Hielo"
        }
    }
}


