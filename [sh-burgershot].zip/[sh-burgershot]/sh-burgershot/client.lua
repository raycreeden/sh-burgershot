local QBCore = exports['qb-core']:GetCoreObject()
local limpiandoBurger = false
local zonasPendientes = {}
local ultimaLimpieza = 0
local markerRotation = 0.0 -- Rotación inicial
local MIN_GRADE_BONO = 3 -- Cambia este número según el rango mínimo permitido

-- ================================
-- DUTY
-- ================================
CreateThread(function()
    local propHash = GetHashKey(Config.DutyProp.model)
    RequestModel(propHash)
    while not HasModelLoaded(propHash) do Wait(10) end

    local obj = CreateObject(propHash, Config.DutyProp.coords.x, Config.DutyProp.coords.y, Config.DutyProp.coords.z, false, false, false)
    FreezeEntityPosition(obj, true)
    SetEntityInvincible(obj, true)
    SetEntityRotation(obj, Config.DutyProp.rotation.x, Config.DutyProp.rotation.y, Config.DutyProp.rotation.z, 2, true)

    exports['qb-target']:AddTargetEntity(obj, {
        options = {
            {
                label = "Iniciar/Salir de Servicio",
                icon = "fas fa-sign-in-alt",
                action = function()
                    local job = QBCore.Functions.GetPlayerData().job
                    if job.name == Config.JobName then
                        TriggerServerEvent("sh-burgershot:toggleDuty")
                    else
                        QBCore.Functions.Notify("No trabajas aquí", "error")
                    end
                end
            },
        },
        distance = 2.0
    })
end)

-- ================================
-- PROPS DE PRODUCCIÓN
-- ================================
CreateThread(function()
    for nombre, punto in pairs(Config.Produccion) do
        if punto.prop then
            local propHash = GetHashKey(punto.prop)
            RequestModel(propHash)
            while not HasModelLoaded(propHash) do Wait(10) end

            local obj = CreateObject(propHash, punto.coords.x, punto.coords.y, punto.coords.z, false, false, false)
            FreezeEntityPosition(obj, true)
            SetEntityInvincible(obj, true)

            if punto.rotation then
                SetEntityRotation(obj, punto.rotation.x, punto.rotation.y, punto.rotation.z, 2, true)
            elseif punto.heading then
                SetEntityHeading(obj, punto.heading)
            end
        end
    end
end)

-- ================================
-- STASH
-- ================================
CreateThread(function()
    exports['qb-target']:AddBoxZone("burgershot_stash", Config.Stash.coords, 1.0, 1.0, {
        name = "burgershot_stash",
        heading = 0,
        debugPoly = false,
        minZ = Config.Stash.coords.z - 1.0,
        maxZ = Config.Stash.coords.z + 1.0,
    }, {
        options = {
            {
                label = "Abrir Almacén",
                icon = "fas fa-box-open",
                action = function()
                    local job = QBCore.Functions.GetPlayerData().job
                    if job.name == Config.JobName and job.onduty then
                        TriggerServerEvent("sh-burgershot:abrirStash")
                    else
                        QBCore.Functions.Notify("Debes estar en servicio", "error")
                    end
                end
            }
        },
        distance = 1.5
    })
end)

-- ================================
-- FACTURAS
-- ================================
CreateThread(function()
    if not Config.Facturas or type(Config.Facturas) ~= "table" then
        print("^1[sh-burgershot] Advertencia: Config.Facturas no está definida o no es una tabla^0")
        return
    end

    for i, coords in ipairs(Config.Facturas) do
        exports['qb-target']:AddBoxZone("burgershot_factura_"..i, coords, 0.5, 0.5, {
            name = "burgershot_factura_"..i,
            heading = 0,
            debugPoly = false,
            minZ = coords.z - 1.0,
            maxZ = coords.z + 1.0
        }, {
            options = {
                {
                    label = "Emitir Factura Cercana",
                    icon = "fas fa-receipt",
                    action = function()
                        local job = QBCore.Functions.GetPlayerData().job
                        if job.name == Config.JobName and job.onduty then
                            TriggerEvent("sh-facturas:emitirFacturaCercana")
                        else
                            QBCore.Functions.Notify("Debes estar en servicio", "error")
                        end
                    end
                },
                {
                    label = "Emitir Factura por ID",
                    icon = "fas fa-keyboard",
                    action = function()
                        local job = QBCore.Functions.GetPlayerData().job
                        if job.name == Config.JobName and job.onduty then
                            TriggerEvent("sh-facturas:emitirFacturaID")
                        else
                            QBCore.Functions.Notify("Debes estar en servicio", "error")
                        end
                    end
                }
            },
            distance = 1.5
        })
    end
end)

-- ================================
-- FUNCIONES DE INVENTARIO
-- ================================
local function hasItems(items, cantidad)
    for item, qty in pairs(items) do
        local has = QBCore.Functions.HasItem(item, qty * cantidad)
        if not has then
            QBCore.Functions.Notify("Faltan: " .. QBCore.Shared.Items[item].label, "error")
            return false
        end
    end
    return true
end

local function removeItems(items, cantidad)
    for item, qty in pairs(items) do
        TriggerServerEvent("sh-burgershot:removeItem", item, qty * cantidad)
    end
end

local function giveItems(items, cantidad)
    for item, qty in pairs(items) do
        TriggerServerEvent("sh-burgershot:giveItem", item, qty * cantidad)
    end
end

local function openCantidadMenu(cantidades, cb)
    local menu = {}
    for _, cant in ipairs(cantidades) do
        menu[#menu+1] = {
            header = tostring(cant).." unidades",
            params = { event = "sh-burgershot:produccionCantidad", args = { cantidad = cant, cb = cb } }
        }
    end
    exports['qb-menu']:openMenu(menu)
end

RegisterNetEvent("sh-burgershot:produccionCantidad", function(data)
    data.cb(data.cantidad)
end)

-- ================================
-- PRODUCCIÓN
-- ================================
for nombre, punto in pairs(Config.Produccion) do
    exports['qb-target']:AddBoxZone("prod_"..nombre, punto.coords, 0.8, 0.8, {
        name = "prod_"..nombre,
        heading = 0,
        debugPoly = false,
        minZ = punto.coords.z - 1,
        maxZ = punto.coords.z + 1
    }, {
        options = {
            {
                icon = "fa-solid fa-utensils",
                label = nombre:gsub("([A-Z])", " %1"),
                job = punto.requiredJob and Config.JobName or nil,
                action = function()
                    local menu = {}
                    for _, cant in ipairs(punto.cantidades) do
                        menu[#menu+1] = {
                            header = tostring(cant).." unidades",
                            params = { event = "sh-burgershot:procesarProduccion", args = { punto = nombre, cantidad = cant } }
                        }
                    end
                    exports['qb-menu']:openMenu(menu)
                end
            }
        },
        distance = 2.0
    })
end

-- Función para procesar con animación y barra
-- Función para procesar con animación y barra
local function procesarConAnimacion(texto, sonido, callback)
    -- reproducir sonido si está definido
    if sonido then
        SendNUIMessage({
            action = "playSound",
            file = sonido
        })
    end

    QBCore.Functions.Progressbar("burgershot_produccion", texto, 4000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {
        animDict = "mini@repair",
        anim = "fixing_a_ped",
        flags = 49,
    }, {}, {}, function()
        QBCore.Functions.Notify("Has completado: " .. texto, "success")
        callback()
    end, function()
        QBCore.Functions.Notify("Acción cancelada", "error")
    end)
end

-- Procesar producción directamente sin callback intermedio
RegisterNetEvent("sh-burgershot:procesarProduccion", function(data)
    local punto = Config.Produccion[data.punto]
    local cantidad = data.cantidad

    -- Determinar sonido según el punto
    local sonido = nil
    if data.punto == "CortarPapas" or data.punto == "CortarTomate" or data.punto == "CortarLechuga" then
        sonido = "cortar"
    elseif data.punto == "FreirPapas" or data.punto == "FreirHamburguesa" then
        sonido = "freir"
    elseif data.punto == "Exprimidos" or data.punto == "ComprarRefresco" then
        sonido = "exprimidor"
    end

    if punto.recipes then
        local recipeMenu = {}
        for outItem, reqItems in pairs(punto.recipes) do
            recipeMenu[#recipeMenu+1] = {
                header = QBCore.Shared.Items[outItem].label,
                params = { event = "sh-burgershot:crearReceta", args = { output = outItem, req = reqItems, cantidad = cantidad, sonido = sonido } }
            }
        end
        exports['qb-menu']:openMenu(recipeMenu)

    elseif punto.input then
        if hasItems({ [punto.input] = 1 }, cantidad) then
            procesarConAnimacion("Procesando " .. QBCore.Shared.Items[punto.output].label, sonido, function()
                removeItems({ [punto.input] = 1 }, cantidad)
                giveItems({ [punto.output] = 1 }, cantidad)
                TriggerEvent('inventory:client:ItemBox', QBCore.Shared.Items[punto.output], 'add')
            end)
        end

    elseif punto.input1 and punto.input2 and punto.input3 then
        local itemsNecesarios = {
            [punto.input1] = 1,
            [punto.input2] = 1,
            [punto.input3] = 1
        }
        if hasItems(itemsNecesarios, cantidad) then
            procesarConAnimacion("Preparando " .. QBCore.Shared.Items[punto.output].label, sonido, function()
                removeItems(itemsNecesarios, cantidad)
                giveItems({ [punto.output] = 1 }, cantidad)
                TriggerEvent('inventory:client:ItemBox', QBCore.Shared.Items[punto.output], 'add')
            end)
        end

    elseif punto.input1 and punto.input2 then
        local itemsNecesarios = {
            [punto.input1] = 1,
            [punto.input2] = 1
        }
        if hasItems(itemsNecesarios, cantidad) then
            procesarConAnimacion("Preparando " .. QBCore.Shared.Items[punto.output].label, sonido, function()
                removeItems(itemsNecesarios, cantidad)
                giveItems({ [punto.output] = 1 }, cantidad)
                TriggerEvent('inventory:client:ItemBox', QBCore.Shared.Items[punto.output], 'add')
            end)
        end

    elseif punto.options and type(punto.options) == "table" then
        local hambMenu = {}
        for _, opt in ipairs(punto.options) do
            hambMenu[#hambMenu+1] = {
                header = opt.label,
                params = { event = "sh-burgershot:retirarHamb", args = { output = opt.item, cantidad = cantidad, sonido = sonido } }
            }
        end
        exports['qb-menu']:openMenu(hambMenu)
    end
end)

RegisterNetEvent("sh-burgershot:crearReceta", function(data)
    if hasItems(data.req, data.cantidad) then
        procesarConAnimacion("Preparando " .. QBCore.Shared.Items[data.output].label, data.sonido, function()
            removeItems(data.req, data.cantidad)
            giveItems({ [data.output] = 1 }, data.cantidad)
            TriggerEvent('inventory:client:ItemBox', QBCore.Shared.Items[data.output], 'add')
        end)
    end
end)

RegisterNetEvent("sh-burgershot:retirarHamb", function(data)
    if hasItems({ [Config.Produccion.RetirarHamburguesa.requiere] = 1 }, data.cantidad) then
        procesarConAnimacion("Entregando " .. QBCore.Shared.Items[data.output].label, data.sonido, function()
            removeItems({ [Config.Produccion.RetirarHamburguesa.requiere] = 1 }, data.cantidad)
            giveItems({ [data.output] = 1 }, data.cantidad)
            TriggerEvent('inventory:client:ItemBox', QBCore.Shared.Items[data.output], 'add')
        end)
    end
end)

-- ================================
-- ZONA PARA HACER PEDIDOS (BURGERSHOT)
-- ================================
CreateThread(function()
    exports['qb-target']:AddBoxZone("burgershot_pedido", Config.Pedidos.coords, 1.0, 1.0, {
        name = "burgershot_pedido",
        heading = 0,
        debugPoly = false,
        minZ = Config.Pedidos.coords.z - 1,
        maxZ = Config.Pedidos.coords.z + 1
    }, {
        options = {
            {
                label = "Hacer Pedido",
                icon = "fas fa-box",
                action = function()
                    local job = QBCore.Functions.GetPlayerData().job
                    if job.name == "burgershot" and job.onduty then
                        openBurgershotMenu()
                    else
                        QBCore.Functions.Notify("Debes estar de servicio en Burgershot", "error")
                    end
                end
            }
        },
        distance = 1.5
    })
end)

-- Menú de selección de producto
function openBurgershotMenu()
    local menu = {
        { header = "📦 Selecciona un producto", isMenuHeader = true }
    }

    for item, data in pairs(Config.Pedidos.items) do
        local itemData = QBCore.Shared.Items[item]
        local label = itemData and itemData.label or item

        table.insert(menu, {
            header = label,
            txt = "Precio por unidad: $"..data.precio,
            params = {
                event = "sh-burgershot:openCantidadMenu",
                args = { item = item, precio = data.precio }
            }
        })
    end

    exports['qb-menu']:openMenu(menu)
end

-- Menú de selección de cantidad
RegisterNetEvent("sh-burgershot:openCantidadMenu", function(data)
    local menu = {
        { header = "Cantidad para "..data.item, isMenuHeader = true }
    }

    for _, qty in ipairs(Config.Pedidos.cantidades) do
        table.insert(menu, {
            header = qty.." unidades",
            txt = "Total: $"..(qty * data.precio),
            params = {
                event = "sh-burgershot:iniciarPedido",
                args = { item = data.item, cantidad = qty, precio = data.precio }
            }
        })
    end

    exports['qb-menu']:openMenu(menu)
end)

-- Iniciar pedido
RegisterNetEvent("sh-burgershot:iniciarPedido", function(data)
    TriggerServerEvent("sh-burgershot:iniciarPedido", data.item, data.cantidad, data.precio)
end)

-- ================================
-- DELIVERY LÓGICA CLIENTE (BURGERSHOT)
-- ================================
local deliveryInProgress = false
local currentPedido = nil
local deliveryVeh = nil
local currentBox = nil

-- 📍 Inicia el delivery desde el server
RegisterNetEvent("sh-burgershot:comenzarDelivery", function(ruta, item, cantidad)
    if deliveryInProgress then
        QBCore.Functions.Notify("Ya tienes un pedido en curso", "error")
        return
    end

    deliveryInProgress = true
    currentPedido = { item = item, amount = cantidad }

    -- 🚚 Spawnear camión en la ubicación inicial
    QBCore.Functions.SpawnVehicle(Config.Delivery.vehiculo, function(veh)
        deliveryVeh = veh
        SetEntityCoords(veh, Config.Delivery.inicio.x, Config.Delivery.inicio.y, Config.Delivery.inicio.z)
        SetEntityHeading(veh, Config.Delivery.inicio.w)
        SetEntityAsMissionEntity(veh, true, true)
        SetVehicleDoorsLocked(veh, 0)
        SetVehicleDoorsLockedForAllPlayers(veh, false)
        TriggerEvent("vehiclekeys:client:SetOwner", QBCore.Functions.GetPlate(veh))
        TaskWarpPedIntoVehicle(PlayerPedId(), veh, -1)
        QBCore.Functions.Notify("Camión listo. Ve al punto de recogida", "primary")

        -- 📍 Crear blip hacia la ubicación de acomodar
        setDeliveryBlip(ruta)
    end, Config.Delivery.inicio, true)
end)

-- Crear blip hacia punto de recogida
function setDeliveryBlip(ruta)
    local blip = AddBlipForCoord(ruta.posAcomodar.x, ruta.posAcomodar.y, ruta.posAcomodar.z)
    SetBlipSprite(blip, 478)
    SetBlipColour(blip, 5)
    SetBlipRoute(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Punto de Recogida")
    EndTextCommandSetBlipName(blip)

    CreateThread(function()
        while deliveryInProgress do
            local coords = GetEntityCoords(PlayerPedId())
            if #(coords - ruta.posAcomodar) < 10.0 then
                -- 🚚 Acomodar camión
                SetEntityCoords(deliveryVeh, ruta.spawnCamion.x, ruta.spawnCamion.y, ruta.spawnCamion.z)
                SetEntityHeading(deliveryVeh, ruta.spawnCamion.w)
                SetVehicleDoorOpen(deliveryVeh, 2, false, false)
                SetVehicleDoorOpen(deliveryVeh, 3, false, false)
                RemoveBlip(blip)
                triggerPickupBox(ruta)
                break
            end
            Wait(1000)
        end
    end)
end

-- Crear caja para recoger
function triggerPickupBox(ruta)
    Wait(500)
    currentBox = CreateObject(`prop_cs_cardbox_01`, ruta.posCaja.x, ruta.posCaja.y, ruta.posCaja.z, true, true, true)
    PlaceObjectOnGroundProperly(currentBox)

    exports['qb-target']:AddBoxZone("pickup_caja_burgershot", ruta.posCaja, 1.0, 1.0, {
        name = "pickup_caja_burgershot",
        heading = 0,
        minZ = ruta.posCaja.z - 1,
        maxZ = ruta.posCaja.z + 1,
        debugPoly = false
    }, {
        options = {
            {
                label = "Recoger Caja",
                icon = "fas fa-box",
                action = function()
                    DeleteEntity(currentBox)
                    exports['qb-target']:RemoveZone("pickup_caja_burgershot")
                    QBCore.Functions.Notify("Caja recogida. Llévala al camión.", "success")
                    attachBoxToPlayer(ruta)
                end
            }
        },
        distance = 2.0
    })
end

-- Adjuntar caja al jugador
function attachBoxToPlayer(ruta)
    local ped = PlayerPedId()
    local box = CreateObject(`prop_cs_cardbox_01`, 0, 0, 0, true, true, true)
    AttachEntityToEntity(box, ped, GetPedBoneIndex(ped, 60309), 0.25, 0.0, -0.1, 0.0, 90.0, 0.0, true, true, false, true, 1, true)

    CreateThread(function()
        local placed = false
        while not placed do
            local coords = GetEntityCoords(ped)
            if #(coords - ruta.posDentroCamion) < 2.0 then
                DrawText3D(ruta.posDentroCamion + vec3(0, 0, 1.0), "~g~[E]~s~ Depositar Caja")
                if IsControlJustReleased(0, 38) then
                    DeleteEntity(box)
                    QBCore.Functions.Notify("Caja cargada. Regresa a Burgershot.", "primary")
                    placed = true
                    setReturnBlip()
                    -- Cerrar puertas cuando jugador se suba
                    CreateThread(function()
                        while deliveryInProgress do
                            Wait(500)
                            if IsPedInVehicle(PlayerPedId(), deliveryVeh, false) then
                                Wait(1000)
                                SetVehicleDoorShut(deliveryVeh, 2, false)
                                SetVehicleDoorShut(deliveryVeh, 3, false)
                                break
                            end
                        end
                    end)
                end
            end
            Wait(0)
        end
    end)
end

-- Blip de regreso
function setReturnBlip()
    local blip = AddBlipForCoord(Config.Delivery.fin.x, Config.Delivery.fin.y, Config.Delivery.fin.z)
    SetBlipSprite(blip, 478)
    SetBlipColour(blip, 5)
    SetBlipRoute(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Regresar a Burgershot")
    EndTextCommandSetBlipName(blip)

    CreateThread(function()
        while deliveryInProgress do
            local coords = GetEntityCoords(PlayerPedId())
            if #(coords - vector3(Config.Delivery.fin.x, Config.Delivery.fin.y, Config.Delivery.fin.z)) < 10.0 then
                RemoveBlip(blip)
                unloadAtStore()
                break
            end
            Wait(1000)
        end
    end)
end

-- Descargar caja en destino final
function unloadAtStore()
    local box = CreateObject(`prop_cs_cardbox_01`, Config.Delivery.fin.x, Config.Delivery.fin.y, Config.Delivery.fin.z, true, true, true)
    PlaceObjectOnGroundProperly(box)

    exports['qb-target']:AddBoxZone("drop_caja_final_burgershot", Config.Delivery.fin, 1.0, 1.0, {
        name = "drop_caja_final_burgershot",
        heading = 0,
        minZ = Config.Delivery.fin.z - 1,
        maxZ = Config.Delivery.fin.z + 1,
        debugPoly = false
    }, {
        options = {
            {
                label = "Descargar Caja",
                icon = "fas fa-box-open",
                action = function()
                    DeleteEntity(box)
                    exports['qb-target']:RemoveZone("drop_caja_final_burgershot")
                    TriggerServerEvent("sh-burgershot:finalizarDelivery", currentPedido.item, currentPedido.amount)

                    -- Eliminar camión
                    CreateThread(function()
                        Wait(500)
                        if DoesEntityExist(deliveryVeh) then
                            SetEntityAsMissionEntity(deliveryVeh, true, true)
                            DeleteVehicle(deliveryVeh)
                        end
                    end)

                    deliveryInProgress = false
                end
            }
        },
        distance = 2.0
    })
end

-- Texto 3D
function DrawText3D(coords, text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextCentre(true)
    SetDrawOrigin(coords.x, coords.y, coords.z, 0)
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(0.0, 0.0)
    ClearDrawOrigin()
end

RegisterNetEvent('sh-burgershot:client:useConsumable', function(itemName, data)
    QBCore.Functions.Progressbar('burgershot_consumable', data.progress.label, data.progress.time, false, true, {
        disableMovement = false,
        disableCarMovement = false,
        disableMouse = false,
        disableCombat = true
    }, {
        animDict = data.animation.animDict,
        anim = data.animation.anim,
        flags = data.animation.flags
    }, {
        model = data.prop.model,
        bone = data.prop.bone,
        coords = data.prop.coords,
        rotation = data.prop.rotation
    }, {}, function()
        ClearPedTasks(PlayerPedId())

        if data.replenish.type == 'Hunger' then
            TriggerServerEvent('sh-burgershot:server:addHunger', data.replenish.replenish)
        elseif data.replenish.type == 'Thirst' then
            TriggerServerEvent('sh-burgershot:server:addThirst', data.replenish.replenish)
        end
    end)
end)

-- Dispensadores de AguaShot
CreateThread(function()
    for _, coords in pairs(Config.AguaShotDispensers) do
        exports['qb-target']:AddBoxZone("agua_shot_"..coords, coords, 0.5, 0.5, {
            name = "agua_shot_"..coords,
            heading = 0,
            debugPoly = false,
            minZ = coords.z - 1.0,
            maxZ = coords.z + 1.0,
        }, {
            options = {
                {
                    icon = "fas fa-tint",
                    label = "Comprar AguaShot",
                    action = function()
                        TriggerEvent("sh-burgershot:comprarAguaShotMenu")
                    end,
                },
            },
            distance = 1.0,
        })
    end
end)

-- Menú de compra de AguaShot
RegisterNetEvent("sh-burgershot:comprarAguaShotMenu", function()
    local precio = Config.AguaShotPrice
    exports['qb-menu']:openMenu({
        { header = "💧 Comprar AguaShot", isMenuHeader = true },
        {
            header = "1 AguaShot ($"..(precio * 1)..")",
            params = { event = "sh-burgershot:comprarAguaShotServer", args = 1 }
        },
        {
            header = "3 AguaShot ($"..(precio * 3)..")",
            params = { event = "sh-burgershot:comprarAguaShotServer", args = 3 }
        },
        {
            header = "5 AguaShot ($"..(precio * 5)..")",
            params = { event = "sh-burgershot:comprarAguaShotServer", args = 5 }
        },
        {
            header = "10 AguaShot ($"..(precio * 10)..")",
            params = { event = "sh-burgershot:comprarAguaShotServer", args = 10 }
        },
        { header = "❌ Cancelar", params = { event = "qb-menu:closeMenu" } }
    })
end)

-- Redirigir al server
RegisterNetEvent("sh-burgershot:comprarAguaShotServer", function(cantidad)
    TriggerServerEvent("sh-burgershot:comprarAguaShot", cantidad)
end)

-- Crear prop y añadir qb-target para la cafetera
-- Crear prop y añadir qb-target para la cafetera
CreateThread(function()
    local p = Config.CafeteraEspresso
    if p and p.prop then
        local model = joaat(p.prop)
        RequestModel(model)
        while not HasModelLoaded(model) do
            Wait(0)
        end

        local obj = CreateObject(model, p.coords.x, p.coords.y, p.coords.z, false, false, false)
        SetEntityHeading(obj, p.heading or 0.0)
        FreezeEntityPosition(obj, true)
        SetEntityInvincible(obj, true)
        SetModelAsNoLongerNeeded(model)

        exports['qb-target']:AddTargetEntity(obj, {
            options = {
                {
                    icon = "fas fa-coffee",
                    label = "Comprar " .. p.label,
                    action = function()
                        TriggerEvent("sh-burgershot:comprarCafeShotMenu")
                    end,
                },
            },
            distance = 1.5
        })
    end
end)

-- Menú de compra de CafeShot
RegisterNetEvent("sh-burgershot:comprarCafeShotMenu", function()
    local p = Config.CafeteraEspresso
    local precio = p.precio
    exports['qb-menu']:openMenu({
        { header = "☕ Comprar " .. p.label, isMenuHeader = true },
        {
            header = "1 "..p.label.." ($"..(precio * 1)..")",
            params = { event = "sh-burgershot:comprarCafeShotServer", args = 1 }
        },
        {
            header = "3 "..p.label.." ($"..(precio * 3)..")",
            params = { event = "sh-burgershot:comprarCafeShotServer", args = 3 }
        },
        {
            header = "5 "..p.label.." ($"..(precio * 5)..")",
            params = { event = "sh-burgershot:comprarCafeShotServer", args = 5 }
        },
        {
            header = "10 "..p.label.." ($"..(precio * 10)..")",
            params = { event = "sh-burgershot:comprarCafeShotServer", args = 10 }
        },
        { header = "❌ Cancelar", params = { event = "qb-menu:closeMenu" } }
    })
end)

RegisterNetEvent("sh-burgershot:comprarCafeShotServer", function(cantidad)
    TriggerServerEvent("sh-burgershot:comprarCafeShot", cantidad)
end)

-- ================================
-- Spawn Boss Menu Props
-- ================================
CreateThread(function()
    for nombre, data in pairs(Config.BossMenuProps) do
        local propHash = GetHashKey(data.model)
        RequestModel(propHash)
        while not HasModelLoaded(propHash) do Wait(10) end

        local obj = CreateObject(propHash, data.coords.x, data.coords.y, data.coords.z, false, false, false)

        if data.rotation then
            SetEntityRotation(obj, data.rotation.x, data.rotation.y, data.rotation.z, 2, true)
        else
            SetEntityHeading(obj, data.heading or 0.0)
        end

        FreezeEntityPosition(obj, true)
        SetEntityInvincible(obj, true)
    end
end)

-- QB-Target para Boss Menu
CreateThread(function()
    exports['qb-target']:AddBoxZone("burgershot_pc_gestion", Config.BossMenu.coords, 1.0, 1.0, {
        name = "burgershot_pc_gestion",
        heading = 0.0,
        debugPoly = false,
        minZ = Config.BossMenu.coords.z - 1.0,
        maxZ = Config.BossMenu.coords.z + 1.0,
    }, {
        options = {
            {
                label = "Gestión Empresarial",
                icon = "fas fa-laptop",
                job = Config.BossMenu.job,
                action = function()
                    local job = QBCore.Functions.GetPlayerData().job
                    if job.grade.level >= Config.BossMenu.minGrade then
                        TriggerEvent("sh-burgershot:openBossMenu")
                    else
                        QBCore.Functions.Notify("No tienes acceso a esta terminal.", "error")
                    end
                end
            }
        },
        distance = 1.5
    })
end)

-- Menú principal
RegisterNetEvent("sh-burgershot:openBossMenu", function()
    local menu = {
        { header = "🖥️ Panel de Gestión - Burgershot", isMenuHeader = true },
        { header = "👥 Ver Compañeros de Servicio", txt = "Empleados actualmente en servicio", params = { event = "sh-burgershot:showOnlineStaff" } },
        { header = "🧑‍💼 Gestión de Empleados", txt = "Contratar o despedir trabajadores", params = { event = "sh-burgershot:menuEmpleados" } },
        { header = "💵 Dar Bono", txt = "Enviar un bono bancario a un empleado", params = { event = "sh-burgershot:darBonoMenu" } },
        { header = "📦 Pedidos", txt = "Ver pedidos realizados", params = { event = "sh-burgershot:menuPedidos" } },
        { header = "📹 Ver Cámaras", txt = "Acceder a las cámaras del local", params = { event = "sh-burgershot:menuCamaras" } },
        { header = "📢 Anuncios", txt = "Enviar anuncios globales del Burgershot", params = { event = "sh-burgershot:menuAnuncios" } },
        { header = "💰 Ver Cuenta", txt = "Fondos disponibles de la empresa", params = { event = "sh-burgershot:verCuenta" } },
        { header = "❌ Cerrar", txt = "", params = { event = "qb-menu:closeMenu" } }
    }
    exports['qb-menu']:openMenu(menu)
end)

-- Mostrar compañeros de servicio
RegisterNetEvent("sh-burgershot:showOnlineStaff", function()
    TriggerServerEvent("sh-burgershot:getOnlineStaff")
end)

RegisterNetEvent("sh-burgershot:client:mostrarStaff", function(staff)
    local menu = {
        { header = "👥 Empleados en Servicio", isMenuHeader = true }
    }

    if #staff == 0 then
        table.insert(menu, {
            header = "No hay empleados activos",
            isMenuHeader = true -- solo texto
        })
    else
        for _, v in ipairs(staff) do
            table.insert(menu, {
                header = v.name,
                txt = "Grado: " .. v.gradeLabel,
                disabled = true -- esto evita que sea clickeable
            })
        end
    end

    table.insert(menu, {
        header = "⬅️ Volver",
        params = { event = "sh-burgershot:openBossMenu" }
    })

    exports['qb-menu']:openMenu(menu)
end)

-- Menú de gestión de empleados
RegisterNetEvent("sh-burgershot:menuEmpleados", function()
    local PlayerData = QBCore.Functions.GetPlayerData()
    local gradeLevel = PlayerData and PlayerData.job and PlayerData.job.grade.level or 0

    local submenu = {
        { header = "🧑‍💼 Gestión de Empleados", isMenuHeader = true },
        { header = "📋 Contratar", txt = "Contratar persona cercana", params = { event = "sh-burgershot:contratarEmpleado" } },
    }

    -- Encargados (2) o más pueden despedir y cambiar rangos
    if gradeLevel >= 2 then
        table.insert(submenu, { header = "📋 Despedir", txt = "Ver empleados y despedir", params = { event = "sh-burgershot:despedirMenuSolicitar" } })
        table.insert(submenu, { header = "📊 Rangos", txt = "Ver y modificar rangos", params = { event = "sh-burgershot:menuRangosSolicitar" } })
    end

    table.insert(submenu, { header = "⬅️ Volver", txt = "", params = { event = "sh-burgershot:openBossMenu" } })
    exports['qb-menu']:openMenu(submenu)
end)

-- 🎯 Contratar persona cercana
RegisterNetEvent("sh-burgershot:contratarEmpleado", function()
    local closestPlayer, closestDistance = QBCore.Functions.GetClosestPlayer()
    if closestPlayer == -1 or closestDistance > 2.0 then
        QBCore.Functions.Notify("No hay nadie cerca", "error")
        return
    end
    TriggerServerEvent("sh-burgershot:contratarEmpleado", GetPlayerServerId(closestPlayer))
end)

-- 🔄 Solicitar empleados para despedir
RegisterNetEvent("sh-burgershot:despedirMenuSolicitar", function()
    QBCore.Functions.TriggerCallback("sh-burgershot:getEmpleados", function(lista)
        exports['qb-menu']:openMenu(BuildDespedirMenuBurgershot(lista))
    end)
end)

-- 📋 Construir menú de despido
function BuildDespedirMenuBurgershot(lista)
    local menu = {
        { header = "👥 Empleados Actuales", isMenuHeader = true }
    }

    if lista and #lista > 0 then
        for _, empleado in ipairs(lista) do
            table.insert(menu, {
                header = empleado.name .. " - Nivel " .. empleado.grade,
                txt = "Click para despedir",
                params = {
                    event = "sh-burgershot:despedirEmpleadoConfirm",
                    args = { id = empleado.citizenid, name = empleado.name }
                }
            })
        end
    else
        table.insert(menu, { header = "⚠️ No hay empleados para mostrar", txt = "Actualmente no hay empleados contratados" })
    end

    table.insert(menu, { header = "⬅️ Volver", txt = "", params = { event = "sh-burgershot:menuEmpleados" } })
    return menu
end

-- ✅ Confirmar despido
RegisterNetEvent("sh-burgershot:despedirEmpleadoConfirm", function(data)
    local menu = {
        { header = "¿Seguro que quieres despedir a " .. data.name .. "?", isMenuHeader = true },
        { header = "✅ Confirmar", txt = "Despedir empleado", params = { isServer = true, event = "sh-burgershot:despedirEmpleado", args = data.id } },
        { header = "❌ Cancelar", txt = "", params = { event = "sh-burgershot:menuEmpleados" } }
    }
    exports['qb-menu']:openMenu(menu)
end)

-- Menú de rangos
RegisterNetEvent("sh-burgershot:mostrarRangosMenu", function(lista)
    local menu = {
        { header = "📊 Empleados Online - Rangos", isMenuHeader = true }
    }

    for _, empleado in ipairs(lista) do
        table.insert(menu, {
            header = empleado.name .. " - Nivel " .. empleado.grade,
            txt = "Cambiar rango",
            params = { event = "sh-burgershot:cambiarRangoMenu", args = { id = empleado.id, name = empleado.name } }
        })
    end

    table.insert(menu, { header = "⬅️ Volver", txt = "", params = { event = "sh-burgershot:menuEmpleados" } })
    exports['qb-menu']:openMenu(menu)
end)

-- Cambiar rango
RegisterNetEvent("sh-burgershot:cambiarRangoMenu", function(data)
    local menu = {
        { header = "📈 Asignar nuevo rango a " .. data.name, isMenuHeader = true },
        { header = "👷 Empleado (0)", params = { isServer = true, event = "sh-burgershot:setNuevoRango", args = { id = data.id, rango = 0 } } },
        { header = "🧑‍💼 Supervisor (1)", params = { isServer = true, event = "sh-burgershot:setNuevoRango", args = { id = data.id, rango = 1 } } },
        { header = "👨‍🔧 Encargado (2)", params = { isServer = true, event = "sh-burgershot:setNuevoRango", args = { id = data.id, rango = 2 } } },
        { header = "🤵 Subjefe (3)", params = { isServer = true, event = "sh-burgershot:setNuevoRango", args = { id = data.id, rango = 3 } } },
        { header = "👑 Jefe (4)", params = { isServer = true, event = "sh-burgershot:setNuevoRango", args = { id = data.id, rango = 4 } } },
        { header = "❌ Cancelar", params = { event = "sh-burgershot:menuRangosSolicitar" } }
    }
    exports['qb-menu']:openMenu(menu)
end)

RegisterNetEvent("sh-burgershot:menuRangosSolicitar", function()
    TriggerServerEvent("sh-burgershot:getEmpleadosOnlineParaRangos")
end)

-- Menú para dar bono
RegisterNetEvent("sh-burgershot:darBonoMenu", function()
    TriggerServerEvent("sh-burgershot:getOnlineStaffForBonus")
end)

-- Lista de empleados en servicio para elegir

RegisterNetEvent("sh-burgershot:client:bonoElegir", function(staff)
    local playerData = QBCore.Functions.GetPlayerData()
    local myGrade = playerData.job.grade.level

    -- Si el jugador no cumple con el rango mínimo, no mostrar menú
    if myGrade < MIN_GRADE_BONO then
        QBCore.Functions.Notify("No tienes rango suficiente para dar bonos.", "error")
        return
    end

    local menu = {
        { header = "💸 Seleccionar Empleado", isMenuHeader = true }
    }

    if #staff == 0 then
        table.insert(menu, { header = "No hay empleados activos", txt = "" })
    else
        for _, v in ipairs(staff) do
            table.insert(menu, {
                header = v.name,
                txt = "Grado: " .. v.gradeLabel,
                params = {
                    event = "sh-burgershot:client:bonoInput",
                    args = { id = v.source, name = v.name }
                }
            })
        end
    end

    table.insert(menu, { header = "⬅️ Volver", params = { event = "sh-burgershot:openBossMenu" } })
    exports['qb-menu']:openMenu(menu)
end)

-- Input de cantidad para el bono
RegisterNetEvent("sh-burgershot:client:bonoInput", function(data)
    local input = exports['qb-input']:ShowInput({
        header = "Dar Bono a " .. data.name,
        submitText = "Enviar Bono",
        inputs = {
            {
                text = "Cantidad ($)",
                name = "monto",
                type = "number",
                isRequired = true
            }
        }
    })

    if input and tonumber(input.monto) then
        TriggerServerEvent("sh-burgershot:enviarBono", data.id, tonumber(input.monto))
    end
end)

-- 📦 Solicitar al servidor los pedidos
RegisterNetEvent("sh-burgershot:solicitarPedidos", function()
    TriggerServerEvent("sh-burgershot:mostrarTotalesPedidos")
end)

-- 📦 Menú de Pedidos (submenú)
RegisterNetEvent("sh-burgershot:menuPedidos", function()
    local menu = {
        { header = "📦 Gestión de Pedidos", isMenuHeader = true },
        { header = "📊 Pedidos Totales", txt = "Estadísticas por empleado", params = { event = "sh-burgershot:solicitarPedidos" } },
        { header = "⬅️ Volver", params = { event = "sh-burgershot:openBossMenu" } }
    }
    exports['qb-menu']:openMenu(menu)
end)

RegisterNetEvent("sh-burgershot:menuCamaras", function()
    local menu = {
        { header = "🎥 Cámaras del Burgershot", isMenuHeader = true }
    }

    for i = 1, #Config.SecurityCameras.cameras do
        local cam = Config.SecurityCameras.cameras[i]
        if cam then
            table.insert(menu, {
                header = cam.label,
                params = {
                    event = "sh-burgershot:client:ActiveCamera",
                    args = i
                }
            })
        end
    end

    table.insert(menu, {
        header = "⬅️ Volver",
        params = { event = "sh-burgershot:openBossMenu" }
    })

    exports['qb-menu']:openMenu(menu)
end)

local createdCamera = 0
local currentCameraIndex = 0

function ChangeSecurityCamera(x, y, z, r)
    if createdCamera ~= 0 then
        DestroyCam(createdCamera, 0)
        createdCamera = 0
    end

    local cam = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
    SetCamCoord(cam, x, y, z)
    SetCamRot(cam, r.x, r.y, r.z, 2)
    RenderScriptCams(true, false, 0, true, true)
    createdCamera = cam
end

function CloseSecurityCamera()
    if createdCamera ~= 0 then
        DestroyCam(createdCamera, 0)
        createdCamera = 0
    end
    RenderScriptCams(false, false, 1, true, true)
    ClearTimecycleModifier()
    SetFocusEntity(PlayerPedId())
    DisplayRadar(true)
    FreezeEntityPosition(PlayerPedId(), false)
end

RegisterNetEvent('sh-burgershot:client:ActiveCamera', function(cameraId)
    local camData = Config.SecurityCameras.cameras[cameraId]
    if not camData then return QBCore.Functions.Notify("Cámara no encontrada", "error") end

    DoScreenFadeOut(250)
    FreezeEntityPosition(PlayerPedId(), true)
    while not IsScreenFadedOut() do Wait(0) end

    SendNUIMessage({
        type = 'enablecam',
        label = camData.label,
        id = cameraId,
        connected = camData.isOnline,
        time = GetClockHours() .. ':' .. GetClockMinutes()
    })

    SetFocusArea(camData.coords.x, camData.coords.y, camData.coords.z, camData.coords.x, camData.coords.y, camData.coords.z)
    ChangeSecurityCamera(camData.coords.x, camData.coords.y, camData.coords.z, camData.r)
    currentCameraIndex = cameraId

    DoScreenFadeIn(250)
end)

CreateThread(function()
    while true do
        local sleep = 2000
        if createdCamera ~= 0 then
            sleep = 5
            SetTimecycleModifier("scanline_cam_cheap")

            -- Salir con BACKSPACE
            if IsControlJustPressed(1, 177) then
                DoScreenFadeOut(250)
                while not IsScreenFadedOut() do Wait(0) end
                CloseSecurityCamera()
                SendNUIMessage({ type = 'disablecam' })
                DoScreenFadeIn(250)
            end

            local getCameraRot = GetCamRot(createdCamera, 2)

            if Config.SecurityCameras.cameras[currentCameraIndex].canRotate then
                if IsControlPressed(0, 32) then -- W
                    SetCamRot(createdCamera, getCameraRot.x + 0.5, 0.0, getCameraRot.z, 2)
                end
                if IsControlPressed(0, 33) then -- S
                    SetCamRot(createdCamera, getCameraRot.x - 0.5, 0.0, getCameraRot.z, 2)
                end
                if IsControlPressed(0, 34) then -- A
                    SetCamRot(createdCamera, getCameraRot.x, 0.0, getCameraRot.z + 0.5, 2)
                end
                if IsControlPressed(0, 35) then -- D
                    SetCamRot(createdCamera, getCameraRot.x, 0.0, getCameraRot.z - 0.5, 2)
                end
            end
        end
        Wait(sleep)
    end
end)

RegisterNetEvent('sh-burgershot:menuAnuncios', function()
    local Player = QBCore.Functions.GetPlayerData()
    if Player.job.name ~= "burgershot" or not Player.job.onduty then
        QBCore.Functions.Notify("No estás autorizado o no estás en servicio", "error")
        return
    end

    local anuncioMenu = {
        { header = "📢 Anuncios - Burgershot", isMenuHeader = true },
        {
            header = "🟢 Anunciar Apertura",
            txt = "Enviar anuncio de que el Burgershot está abierto",
            params = {
                event = "sh-burgershot:anunciar",
                args = { tipo = "abierto" }
            }
        },
        {
            header = "🔴 Anunciar Cierre",
            txt = "Enviar anuncio de que el Burgershot está cerrado",
            params = {
                event = "sh-burgershot:anunciar",
                args = { tipo = "cerrado" }
            }
        },
        {
            header = "✍️ Enviar Personalizado",
            txt = "Escribe un mensaje personalizado",
            params = {
                event = "sh-burgershot:anuncioPersonalizado"
            }
        },
        {
            header = "⬅️ Volver",
            txt = "",
            params = {
                event = "sh-burgershot:openBossMenu"
            }
        },
    }

    exports['qb-menu']:openMenu(anuncioMenu)
end)

RegisterNetEvent('sh-burgershot:anunciar', function(data)
    local tipo = data.tipo
    local mensaje = ""

    if tipo == "abierto" then
        mensaje = "🟢 ¡Burgershot ha abierto sus puertas!"
    elseif tipo == "cerrado" then
        mensaje = "🔴 Burgershot ha cerrado sus puertas."
    else
        return
    end

    TriggerServerEvent("sh-burgershot:enviarAnuncio", mensaje)
end)

RegisterNetEvent('sh-burgershot:anuncioPersonalizado', function()
    local dialog = exports['qb-input']:ShowInput({
        header = "✍️ Anuncio Personalizado",
        submitText = "Enviar",
        inputs = {
            {
                type = 'text',
                isRequired = true,
                name = 'mensaje',
                text = 'Escribe tu anuncio',
            }
        }
    })

    if dialog and dialog.mensaje and dialog.mensaje ~= "" then
        TriggerServerEvent("sh-burgershot:enviarAnuncio", "📢 " .. dialog.mensaje)
    else
        QBCore.Functions.Notify("Mensaje inválido.", "error")
    end
end)

-- Mostrar anuncio en pantalla
RegisterNetEvent("sh-burgershot:mostrarAnuncio", function(mensaje)
    SendNUIMessage({
        action = "mostrarAnuncio",
        texto = mensaje
    })

    -- Ocultar después de 2.5 segundos
    SetTimeout(2500, function()
        SendNUIMessage({ action = "ocultarAnuncio" })
        SetNuiFocus(false, false)
    end)
end)

-- 📊 Ver cuenta
RegisterNetEvent("sh-burgershot:verCuenta", function()
    TriggerServerEvent("sh-burgershot:getCuentaEmpresa")
end)

RegisterNetEvent("sh-burgershot:client:mostrarCuenta", function(monto)
    local job = QBCore.Functions.GetPlayerData().job
    local menu = {
        { header = "💰 Cuenta del Burgershot", isMenuHeader = true },
        { header = "Fondos actuales: $" .. monto, txt = "" },
        { header = "📥 Ingresar Dinero", txt = "Desde tu banco personal", params = { event = "sh-burgershot:depositarEmpresa" } }
    }

    if job.grade.level >= 2 then
        table.insert(menu, { header = "💸 Retirar Dinero", txt = "Hacia tu banco personal", params = { event = "sh-burgershot:retirarEmpresa" } })
        table.insert(menu, { header = "📜 Ver Movimientos", txt = "Ver historial de transacciones", params = { event = "sh-burgershot:verMovimientos" } })
    end

    table.insert(menu, { header = "⬅️ Volver", params = { event = "sh-burgershot:openBossMenu" } })
    exports['qb-menu']:openMenu(menu)
end)

-- 📥 Depositar
RegisterNetEvent("sh-burgershot:depositarEmpresa", function()
    local input = exports['qb-input']:ShowInput({
        header = "📥 Ingresar Dinero a la Empresa",
        submitText = "Depositar",
        inputs = {
            { text = "Cantidad ($)", name = "cantidad", type = "number", isRequired = true }
        }
    })

    if input and tonumber(input.cantidad) then
        TriggerServerEvent("sh-burgershot:depositarEmpresa", tonumber(input.cantidad))
    end
end)

-- 💸 Retirar
RegisterNetEvent("sh-burgershot:retirarEmpresa", function()
    local input = exports['qb-input']:ShowInput({
        header = "💸 Retirar Dinero de la Empresa",
        submitText = "Retirar",
        inputs = {
            { text = "Cantidad ($)", name = "cantidad", type = "number", isRequired = true }
        }
    })

    if input and tonumber(input.cantidad) then
        TriggerServerEvent("sh-burgershot:retirarEmpresa", tonumber(input.cantidad))
    end
end)

-- 📜 Ver movimientos
RegisterNetEvent("sh-burgershot:verMovimientos", function()
    TriggerServerEvent("sh-burgershot:getMovimientos")
end)

RegisterNetEvent("sh-burgershot:client:mostrarMovimientos", function(movimientos)
    local menu = {
        { header = "📜 Movimientos - Burgershot", isMenuHeader = true }
    }

    if #movimientos == 0 then
        table.insert(menu, { header = "No hay movimientos registrados", txt = "" })
    else
        for _, v in ipairs(movimientos) do
            local tipo = v.tipo == "depositar" and "Depósito"
                      or v.tipo == "retirar" and "Retiro"
                      or v.tipo == "darbono" and "Bono"
                      or "Desconocido"

            local actorTxt = v.actorName and v.actorName ~= "" and (" → " .. v.actorName) or ""

            table.insert(menu, {
                header = tipo .. actorTxt,
                txt = "$" .. v.cantidad
            })
        end
    end

    table.insert(menu, { header = "⬅️ Volver", params = { event = "sh-burgershot:verCuenta" } })
    exports['qb-menu']:openMenu(menu)
end)

-- 📦 Crear botón de pánico en Burgershot
CreateThread(function()
    local cfg = Config.PanicButton

    -- Crear prop
    local prop = CreateObject(`hei_prop_bank_alarm_01`, cfg.coords.x, cfg.coords.y, cfg.coords.z, false, false, false)
    SetEntityRotation(prop, cfg.rot.x, cfg.rot.y, cfg.rot.z, 2, true)
    SetEntityInvincible(prop, true)
    SetEntityAsMissionEntity(prop, true, true)
    FreezeEntityPosition(prop, true)

    -- Agregar qb-target
    exports['qb-target']:AddTargetEntity(prop, {
        options = {
            {
                icon = "fas fa-bell",
                label = "🚨 Apretar Botón Antipánico",
                action = function()
                    local player = QBCore.Functions.GetPlayerData()
                    if player.job.name == cfg.job then
                        if player.job.onduty then
                            TriggerServerEvent("sh-burgershot:enviarAlertaPanico", cfg.coords)
                            QBCore.Functions.Notify("Alerta enviada a la policía", "success", 5000)
                        else
                            QBCore.Functions.Notify("Debes estar de servicio para usar el botón", "error", 5000)
                        end
                    else
                        QBCore.Functions.Notify("No trabajas aquí", "error", 5000)
                    end
                end,
                canInteract = function()
                    local player = QBCore.Functions.GetPlayerData()
                    return player.job.name == cfg.job
                end
            }
        },
        distance = 2.0
    })
end)

-- 📢 Evento que reciben los policías
RegisterNetEvent("sh-burgershot:mostrarAlertaPanico", function(coords)
    QBCore.Functions.Notify("🚨 ¡Botón de pánico activado en Burgershot!", "error", 7000)

    local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(blip, 161)
    SetBlipScale(blip, 1.2)
    SetBlipColour(blip, 1)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("🚨 Botón de Pánico")
    EndTextCommandSetBlipName(blip)
    SetBlipFlashes(blip, true)

    Wait(45000)
    RemoveBlip(blip)
end)

local spawnedVeh = nil

-- Crear NPC y Target
CreateThread(function()
    local cfg = Config.CompanyVehiclePed

    RequestModel(cfg.model)
    while not HasModelLoaded(cfg.model) do Wait(0) end

    local ped = CreatePed(0, cfg.model, cfg.coords.x, cfg.coords.y, cfg.coords.z, cfg.coords.w, false, false)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    FreezeEntityPosition(ped, true)
    TaskStartScenarioInPlace(ped, "WORLD_HUMAN_CLIPBOARD", 0, true)

    exports['qb-target']:AddTargetEntity(ped, {
        options = {
            {
                label = "Usar Vehículo de Empresa",
                icon = "fas fa-truck",
                job = cfg.job,
                canInteract = function()
                    local player = QBCore.Functions.GetPlayerData()
                    return player.job and player.job.name == cfg.job and player.job.onduty
                end,
                action = function()
                    local menu = {
                        { header = "🚗 Vehículos de Empresa", isMenuHeader = true },
                        {
                            header = "Novak (Burgershot)",
                            txt = "Vehículo oficial de la empresa",
                            params = { event = "sh-burgershot:spawnCompanyVehicle" }
                        },
                        { header = "❌ Cerrar", params = { event = "qb-menu:closeMenu" } }
                    }
                    exports['qb-menu']:openMenu(menu)
                end
            },
            {
                label = "Guardar Vehículo",
                icon = "fas fa-car-side",
                job = cfg.job,
                canInteract = function()
                    return IsPedInAnyVehicle(PlayerPedId(), false)
                end,
                action = function()
                    local veh = GetVehiclePedIsIn(PlayerPedId(), false)
                    if DoesEntityExist(veh) then
                        DeleteVehicle(veh)
                        spawnedVeh = nil
                        QBCore.Functions.Notify("Vehículo guardado correctamente", "success")
                    end
                end
            }
        },
        distance = 3.5
    })
end)

-- Spawn del Novak personalizado
RegisterNetEvent("sh-burgershot:spawnCompanyVehicle", function()
    local cfg = Config.CompanyVehiclePed
    local model = cfg.vehicleModel

    RequestModel(model)
    while not HasModelLoaded(model) do Wait(0) end

    if spawnedVeh and DoesEntityExist(spawnedVeh) then
        DeleteVehicle(spawnedVeh)
    end

    local coords = cfg.vehicleSpawn
    spawnedVeh = CreateVehicle(model, coords.x, coords.y, coords.z, coords.w, true, false)

    -- Colores
    SetVehicleColours(spawnedVeh, 39, 39) -- Azul mate
    SetVehicleExtraColours(spawnedVeh, 83, 83) -- Perlado rojo mate

    -- Mod Kit
    SetVehicleModKit(spawnedVeh, 0)

    -- Spoiler (mod index 0)
    SetVehicleMod(spawnedVeh, 0, 6, false) -- 7º spoiler (index 6)

    -- Livery Burger Shot (modType 48, última opción = 9)
    SetVehicleMod(spawnedVeh, 48, 9, false)

    -- Ruedas
    SetVehicleWheelType(spawnedVeh, 0) -- tipo default
    SetVehicleMod(spawnedVeh, 23, 0, false) -- modelo de llanta base
    SetVehicleExtraColours(spawnedVeh, 131, 131) -- ruedas blancas mate + perlado rojo mate

    -- Sentar jugador dentro
    TaskWarpPedIntoVehicle(PlayerPedId(), spawnedVeh, -1)
    SetVehicleEngineOn(spawnedVeh, true, true, false)

    -- Dar llaves
    TriggerEvent("vehiclekeys:client:SetOwner", GetVehicleNumberPlateText(spawnedVeh))
end)

-- Crear prop del guardarropa
CreateThread(function()
    local cfg = Config.WardrobeProp

    RequestModel(cfg.model)
    while not HasModelLoaded(cfg.model) do Wait(0) end

    local prop = CreateObject(GetHashKey(cfg.model), cfg.coords.x, cfg.coords.y, cfg.coords.z, false, false, false)
    SetEntityHeading(prop, cfg.heading)
    FreezeEntityPosition(prop, true)
    SetEntityInvincible(prop, true)
end)

-- ============================
-- 📁 sh-burgershot | client.lua
-- Vestuario SIN ilenium-appearance
-- ============================

RegisterNetEvent('sh-burgershot:menuRopa', function()
    local menu = {
        { header = '👕 Vestuario del Burgershot', isMenuHeader = true },
        {
            header = '🧥 Con Estilo',
            txt = 'Ponerse ropa de trabajo',
            params = { event = 'sh-burgershot:ponerRopaTrabajo' }
        },
        {
            header = '🧥 Con Estilo 2',
            txt = 'Otra variante del uniforme',
            params = { event = 'sh-burgershot:ponerRopaTrabajo2' }
        },
        {
            header = '👖 Ropa Civil',
            txt = 'Volver a tu vestimenta anterior',
            params = { event = 'sh-burgershot:ponerRopaCivil' }
        },
        { header = '❌ Cancelar', txt = '', params = { event = 'qb-menu:closeMenu' } }
    }
    exports['qb-menu']:openMenu(menu)
end)

local function reproducirAnimCambioRopa()
    local ped = PlayerPedId()
    RequestAnimDict("clothingtrousers")
    while not HasAnimDictLoaded("clothingtrousers") do Wait(0) end
    TaskPlayAnim(ped, "clothingtrousers", "try_trousers_positive_b", 3.0, -1, -1, 49, 0, 0, 0, 0)
    Wait(3000)
    ClearPedTasks(ped)
end

-- Variables para ropa
local ropaCivil = nil

RegisterNetEvent('sh-burgershot:ponerRopaTrabajo', function()
    local ped = PlayerPedId()

    -- Guardar ropa actual solo una vez
    if not ropaCivil then
        ropaCivil = {}
        for i = 0, 11 do
            ropaCivil[i] = { drawable = GetPedDrawableVariation(ped, i), texture = GetPedTextureVariation(ped, i) }
        end
        for i = 0, 7 do
            ropaCivil['prop'..i] = { drawable = GetPedPropIndex(ped, i), texture = GetPedPropTextureIndex(ped, i) }
        end
    end

    local model = GetEntityModel(ped)
    local genero = (model == GetHashKey("mp_m_freemode_01")) and 'male' or 'female'
    local ropa = Config.RopaTrabajo[genero] -- definido en Config o en este archivo

    for _, v in pairs(ropa) do
        if v.component then
            SetPedComponentVariation(ped, v.component, v.drawable, v.texture, 0)
        elseif v.prop then
            SetPedPropIndex(ped, v.prop, v.drawable, v.texture, true)
        end
    end
    reproducirAnimCambioRopa()
end)

RegisterNetEvent('sh-burgershot:ponerRopaTrabajo2', function()
    local ped = PlayerPedId()

    if not ropaCivil then
        ropaCivil = {}
        for i = 0, 11 do
            ropaCivil[i] = { drawable = GetPedDrawableVariation(ped, i), texture = GetPedTextureVariation(ped, i) }
        end
        for i = 0, 7 do
            ropaCivil['prop'..i] = { drawable = GetPedPropIndex(ped, i), texture = GetPedPropTextureIndex(ped, i) }
        end
    end

    local model = GetEntityModel(ped)
    local genero = (model == GetHashKey("mp_m_freemode_01")) and 'male' or 'female'
    local ropa = Config.RopaTrabajo2[genero]

    for _, v in pairs(ropa) do
        if v.component then
            SetPedComponentVariation(ped, v.component, v.drawable, v.texture, 0)
        elseif v.prop then
            SetPedPropIndex(ped, v.prop, v.drawable, v.texture, true)
        end
    end
    reproducirAnimCambioRopa()
end)

RegisterNetEvent('sh-burgershot:ponerRopaCivil', function()
    local ped = PlayerPedId()
    if not ropaCivil then
        QBCore.Functions.Notify("No se pudo recuperar tu ropa anterior", "error")
        return
    end

    for i = 0, 11 do
        local r = ropaCivil[i]
        if r then
            SetPedComponentVariation(ped, i, r.drawable, r.texture, 0)
        end
    end

    for i = 0, 7 do
        local p = ropaCivil['prop'..i]
        if p and p.drawable ~= -1 then
            SetPedPropIndex(ped, i, p.drawable, p.texture, true)
        else
            ClearPedProp(ped, i)
        end
    end

    ropaCivil = nil
    reproducirAnimCambioRopa()
end)

-- 📌 QB-Target en tu ubicación
CreateThread(function()
    exports['qb-target']:AddBoxZone("vestidor_burgershot", vector3(-1198.44, -901.59, 13.24), 1.2, 1.2, {
        name = "vestidor_burgershot",
        heading = 0,
        debugPoly = false,
        minZ = 12.24,
        maxZ = 14.24,
    }, {
        options = {
            {
                icon = "fas fa-tshirt",
                label = "Usar Ropa de Trabajo",
                action = function()
                    TriggerEvent("sh-burgershot:menuRopa")
                end,
                job = "burgershot"
            }
        },
        distance = 1.5
    })
end)

-- 📌 Comando manual
RegisterCommand("burgerropa", function()
    local job = QBCore.Functions.GetPlayerData().job
    if job and job.name == "burgershot" then
        TriggerEvent("sh-burgershot:menuRopa")
    else
        QBCore.Functions.Notify("No trabajas en el Burgershot", "error")
    end
end, false)

local radioAbierta = false

-- Abrir radio con F6 solo si es del job Burgershot y tiene item radio
RegisterCommand("+abrirBurgershotRadio", function()
    local PlayerData = QBCore.Functions.GetPlayerData()
    if PlayerData.job and PlayerData.job.name == "burgershot" then
        QBCore.Functions.TriggerCallback("sh-burgershot:checkRadioItem", function(tieneRadio)
            if tieneRadio then
                SetNuiFocus(true, true) -- Permitir click + teclado en NUI
                SendNUIMessage({ action = "abrirRadio" })
                radioAbierta = true
                TriggerServerEvent("sh-burgershot:solicitarUsuariosRadio")
            else
                QBCore.Functions.Notify("Necesitas una radio para acceder.", "error")
            end
        end)
    else
        QBCore.Functions.Notify("No tienes acceso a la radio Burgershot.", "error")
    end
end, false)

RegisterCommand("-abrirBurgershotRadio", function() end, false)

-- Mapear tecla F6
RegisterKeyMapping("+abrirBurgershotRadio", "Abrir Radio Burgershot", "keyboard", "F6")

-- === Callbacks desde NUI ===
RegisterNUICallback("cerrarRadio", function(_, cb)
    cerrarRadioCliente()
    cb("ok")
end)

RegisterNUICallback("seleccionarFrecuencia", function(data, cb)
    local freq = tonumber(data.frecuencia)
    if freq then
        exports["pma-voice"]:setRadioChannel(freq)
        exports["pma-voice"]:setVoiceProperty("radioEnabled", true)
        TriggerServerEvent("sh-burgershot:cambiarFrecuencia", freq)
    end
    cb("ok")
end)

-- Recibir lista de usuarios para mostrar en NUI
RegisterNetEvent("sh-burgershot:enviarUsuariosRadio", function(usuarios)
    -- Convertir tabla indexada por src a array para NUI
    local lista = {}
    for _, datos in pairs(usuarios) do
        table.insert(lista, datos)
    end
    SendNUIMessage({
        action = "actualizarUsuarios",
        usuarios = lista,
        total = #lista
    })
end)

-- Cierre de emergencia con BACKSPACE o ESC
CreateThread(function()
    while true do
        Wait(0)
        if radioAbierta then
            -- BACKSPACE
            if IsControlJustReleased(0, 177) then
                cerrarRadioCliente()
            end
            -- ESC (tecla física)
            if IsControlJustReleased(0, 322) then
                cerrarRadioCliente()
            end
        end
    end
end)

function cerrarRadioCliente()
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "cerrarRadio" })
    radioAbierta = false
    -- ❌ ya no borramos del server aquí
end

-- Nuevo callback para desconectar de la frecuencia
RegisterNUICallback("desconectarFrecuencia", function(_, cb)
    exports["pma-voice"]:setRadioChannel(0) -- salir de radio
    exports["pma-voice"]:setVoiceProperty("radioEnabled", false)
    TriggerServerEvent("sh-burgershot:cerrarRadio") -- aquí sí lo borramos del server
    cb("ok")
end)

CreateThread(function()
    for _, coords in ipairs(Config.BurgershotMenuLocations) do
        exports['qb-target']:AddBoxZone("burgershot_menu_".._, coords, 1.0, 1.0, {
            name = "burgershot_menu_".._,
            heading = 0,
            debugPoly = false,
            minZ = coords.z - 1,
            maxZ = coords.z + 1
        }, {
            options = {
                {
                    type = "client",
                    event = "sh-burgershot:showMenu",
                    icon = "fas fa-utensils",
                    label = "Ver Menú"
                }
            },
            distance = 2.0
        })
    end
end)

RegisterNetEvent("sh-burgershot:showMenu", function()
    local menu = {
        {
            header = "🍔 Menú de Burgershot",
            isMenuHeader = true
        }
    }

    for _, item in ipairs(Config.BurgershotItems) do
        menu[#menu + 1] = {
            header = item.label,
            txt = "", -- aquí podrías poner precio o descripción si quieres
            disabled = true
        }
    end

    exports['qb-menu']:openMenu(menu)
end)

-- Crear zonas de stash temporales
CreateThread(function()
    for _, stash in ipairs(Config.StashTemporales) do
        exports['qb-target']:AddBoxZone(stash.name, stash.coords, 0.6, 0.6, {
            name = stash.name,
            heading = 0,
            debugPoly = false,
            minZ = stash.coords.z - 1.0,
            maxZ = stash.coords.z + 1.0,
        }, {
            options = {
                {
                    label = "Entregar Pedido",
                    icon = "fas fa-box",
                    action = function()
                        TriggerServerEvent("sh-burgershot:abrirStashTemporal", stash.name)
                    end
                }
            },
            distance = 1.5
        })
    end
end)

-- Crear prop de limpieza
CreateThread(function()
    local propData = Config.PropLimpieza
    if propData and propData.model then
        local propHash = GetHashKey(propData.model)
        RequestModel(propHash)
        while not HasModelLoaded(propHash) do
            Wait(10)
        end

        local obj = CreateObject(propHash, propData.coords.x, propData.coords.y, propData.coords.z, false, false, false)
        SetEntityHeading(obj, propData.heading or 0.0)
        FreezeEntityPosition(obj, true)
        SetEntityInvincible(obj, true)
    end
end)

-- 📍 Punto de inicio limpieza
CreateThread(function()
    exports['qb-target']:AddBoxZone("inicio_limpieza_burger", Config.LimpiezaBurger.inicio, 0.8, 0.8, {
        name = "inicio_limpieza_burger",
        heading = 0,
        debugPoly = false,
        minZ = Config.LimpiezaBurger.inicio.z - 0.5,
        maxZ = Config.LimpiezaBurger.inicio.z + 1.0,
    }, {
        options = {
            {
                icon = "fas fa-broom",
                label = "Limpiar Burgershot",
                action = function()
                    TriggerEvent("sh-burgershot:iniciarLimpieza")
                end
            }
        },
        distance = 2.0
    })
end)

-- 📍 Iniciar limpieza (ahora delega cooldown al server)
RegisterNetEvent("sh-burgershot:iniciarLimpieza", function()
    TriggerServerEvent("sh-burgershot:checkCooldownLimpieza")
end)

-- 📍 El server autoriza y arranca limpieza
RegisterNetEvent("sh-burgershot:cooldownOK", function()
    QBCore.Functions.Notify("Has comenzado a limpiar el Burgershot. Completa todas las zonas.", "success")
    limpiandoBurger = true
    zonasPendientes = {}
    for _, coords in ipairs(Config.LimpiezaBurger.zonas) do
        zonasPendientes[#zonasPendientes + 1] = coords
        agregarZonaLimpieza(coords)
    end
end)

-- cuando terminas todas las zonas:
if #zonasPendientes == 0 then
    limpiandoBurger = false
    TriggerServerEvent("sh-burgershot:finalizarLimpieza")
end

-- 📍 Agregar zona con qb-target
function agregarZonaLimpieza(coords)
    exports['qb-target']:AddBoxZone("limpieza_"..coords.x, coords, 0.7, 0.7, {
        name = "limpieza_"..coords.x,
        heading = 0,
        debugPoly = false,
        minZ = coords.z - 0.5,
        maxZ = coords.z + 1.0,
    }, {
        options = {
            {
                icon = "fas fa-broom",
                label = "Limpiar",
                action = function()
                    limpiarZona(coords)
                end,
                canInteract = function()
                    return limpiandoBurger
                end
            }
        },
        distance = 2.5
    })
end

-- 🧹 Función de limpieza
function limpiarZona(coords)
    local playerPed = PlayerPedId()
    local mopHash = GetHashKey(Config.LimpiezaBurger.propMopa)
    RequestModel(mopHash)
    while not HasModelLoaded(mopHash) do Wait(10) end
    local mop = CreateObject(mopHash, 0, 0, 0, true, true, true)
    AttachEntityToEntity(mop, playerPed, GetPedBoneIndex(playerPed, 28422), 0.0, 0.0, -0.6, 0.0, 0.0, 0.0, true, true, false, true, 1, true)

    RequestAnimDict("amb@world_human_janitor@male@idle_a")
    while not HasAnimDictLoaded("amb@world_human_janitor@male@idle_a") do Wait(10) end

    QBCore.Functions.Progressbar("limpiar_burger", "Limpiando zona...", 7000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {
        animDict = "amb@world_human_janitor@male@idle_a",
        anim = "idle_a",
        flags = 1
    }, {}, {}, function() -- On finish
        ClearPedTasks(playerPed)
        DeleteObject(mop)

        -- Eliminar zona completada
        for i, v in ipairs(zonasPendientes) do
            if v.x == coords.x and v.y == coords.y and v.z == coords.z then
                table.remove(zonasPendientes, i)
                break
            end
        end

        -- Avisar cuántas quedan
        QBCore.Functions.Notify("Zona limpia. Quedan " .. #zonasPendientes .. " zonas.", "success")

        -- Si no quedan → pago
        if #zonasPendientes == 0 then
            limpiandoBurger = false
            TriggerServerEvent("sh-burgershot:pagarLimpieza")
        end
    end, function() -- On cancel
        ClearPedTasks(playerPed)
        DeleteObject(mop)
        QBCore.Functions.Notify("Limpieza cancelada.", "error")
    end)
end

-- Marker único para zonas pendientes
CreateThread(function()
    while true do
        if limpiandoBurger and #zonasPendientes > 0 then
            markerRotation = (markerRotation + 0.5) % 360 -- velocidad de giro
            for _, coords in ipairs(zonasPendientes) do
                DrawMarker(
                    Config.LimpiezaBurger.marker.type,
                    coords.x, coords.y, coords.z + 0.15, -- altura ajustada
                    0.0, 0.0, 0.0,                       -- dirección
                    0.0, 0.0, markerRotation,            -- rotación en tiempo real
                    Config.LimpiezaBurger.marker.size.x,
                    Config.LimpiezaBurger.marker.size.y,
                    Config.LimpiezaBurger.marker.size.z,
                    Config.LimpiezaBurger.marker.color.r,
                    Config.LimpiezaBurger.marker.color.g,
                    Config.LimpiezaBurger.marker.color.b,
                    Config.LimpiezaBurger.marker.color.a,
                    false, false, 2, false, nil, nil, false
                )
            end
            Wait(0)
        else
            Wait(500)
        end
    end
end)

-- 🔹 Crear props especiales al iniciar
CreateThread(function()
    for _, propData in ipairs(Config.PropsEspeciales) do
        local modelHash = GetHashKey(propData.model)

        -- Cargar modelo
        RequestModel(modelHash)
        local timeout = 0
        while not HasModelLoaded(modelHash) and timeout < 500 do
            Wait(10)
            timeout = timeout + 1
        end

        if HasModelLoaded(modelHash) then
            local obj = CreateObject(
                modelHash,
                propData.coords.x,
                propData.coords.y,
                propData.coords.z - 1.0, -- ajuste altura
                false, false, false
            )

            -- Rotación con valores por defecto si no están en config
            local rot = propData.rotation or vector3(0.0, 0.0, 0.0)
            SetEntityRotation(obj, rot.x, rot.y, rot.z, 2, true)

            FreezeEntityPosition(obj, true)
            SetEntityInvincible(obj, true)
            SetEntityAsMissionEntity(obj, true, true)
        else
            print(("[Burgershot] No se pudo cargar el modelo: %s"):format(propData.model))
        end
    end
end)

-- 🔹 QB-Target para abrir menú de recetas
CreateThread(function()
    exports['qb-target']:AddBoxZone("burgershot_recetas", Config.RecetasMenu.coords, 0.6, 0.6, {
        name = "burgershot_recetas",
        heading = 0.0,
        debugPoly = false,
        minZ = Config.RecetasMenu.coords.z - 1.0,
        maxZ = Config.RecetasMenu.coords.z + 1.0,
    }, {
        options = {
            {
                label = "📜 Recetas",
                icon = "fas fa-book-open",
                job = Config.RecetasMenu.job,
                action = function()
                    local job = QBCore.Functions.GetPlayerData().job
                    if job.grade.level >= Config.RecetasMenu.minGrade then
                        TriggerEvent("sh-burgershot:abrirMenuRecetas")
                    else
                        QBCore.Functions.Notify("No tienes acceso a las recetas.", "error")
                    end
                end
            }
        },
        distance = 1.5
    })
end)

-- 📖 Evento para abrir menú principal de recetas
RegisterNetEvent("sh-burgershot:abrirMenuRecetas", function()
    local menu = {
        { header = "📜 Recetas - Burgershot", isMenuHeader = true }
    }

    for _, receta in ipairs(Config.RecetasBurgershot) do
        table.insert(menu, {
            header = receta.nombre,
            txt = "Ver ingredientes",
            params = {
                event = "sh-burgershot:verRecetaDetalle",
                args = receta
            }
        })
    end

    table.insert(menu, {
        header = "⬅️ Cerrar",
        params = { event = "qb-menu:closeMenu" }
    })

    exports['qb-menu']:openMenu(menu)
end)

-- 📄 Evento para mostrar ingredientes de una receta
RegisterNetEvent("sh-burgershot:verRecetaDetalle", function(receta)
    local detalleMenu = {
        { header = receta.nombre, isMenuHeader = true }
    }

    for _, ing in ipairs(receta.ingredientes) do
        table.insert(detalleMenu, {
            header = "• " .. ing,
            isMenuHeader = true
        })
    end

    table.insert(detalleMenu, {
        header = "⬅️ Volver",
        params = { event = "sh-burgershot:abrirMenuRecetas" }
    })

    exports['qb-menu']:openMenu(detalleMenu)
end)
