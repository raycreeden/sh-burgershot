local QBCore = exports['qb-core']:GetCoreObject()
local ultimoAnuncio = 0
local tiempoEspera = 10 * 60 -- 10 minutos en segundos
local jugadoresLimpiando = {} -- estado por jugador
local ultimaLimpiezaGlobal = 0



-- Crear tablas para Burgershot si no existen
CreateThread(function()
    exports.oxmysql:query([[
        CREATE TABLE IF NOT EXISTS burgershot_pedidos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            citizenid VARCHAR(50) NOT NULL,
            item VARCHAR(50) NOT NULL,
            amount INT NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    ]])

    exports.oxmysql:query([[
        CREATE TABLE IF NOT EXISTS burgershot_movimientos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            citizenid VARCHAR(50) NOT NULL,
            targetid VARCHAR(50),
            tipo VARCHAR(50) NOT NULL,
            cantidad INT NOT NULL,
            fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    ]])
end)

-- 📜 Función para registrar movimientos en la tabla de Burgershot
-- 📜 Función para registrar movimientos en la tabla de Burgershot
local function registrarMovimiento(citizenid, targetid, tipo, cantidad)
    local Player = QBCore.Functions.GetPlayerByCitizenId(citizenid)
    local actorName = ""

    if Player then
        actorName = Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname
    end

    exports.oxmysql:insert(
        'INSERT INTO burgershot_movimientos (citizenid, actorname, targetid, tipo, cantidad) VALUES (?, ?, ?, ?, ?)',
        { citizenid, actorName, targetid or nil, tipo, cantidad }
    )
end

-- Iniciar / salir servicio
RegisterServerEvent("sh-burgershot:toggleDuty", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    if Player.PlayerData.job.name ~= Config.JobName then return end

    local onduty = Player.PlayerData.job.onduty
    Player.Functions.SetJobDuty(not onduty)
    TriggerClientEvent("QBCore:Notify", src, not onduty and "Ahora estás en servicio" or "Has salido de servicio", "success")
end)

-- Abrir stash
RegisterServerEvent("sh-burgershot:abrirStash", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    if Player.PlayerData.job.name ~= Config.JobName or not Player.PlayerData.job.onduty then
        TriggerClientEvent("QBCore:Notify", src, "No tienes permiso", "error")
        return
    end

    exports['qb-inventory']:OpenInventory(src, Config.Stash.stashName, {
        label = Config.Stash.label,
        maxweight = Config.Stash.maxweight,
        slots = Config.Stash.slots
    })
end)

-- =========================================================
-- NUEVO: Manejo de ítems
-- =========================================================
RegisterServerEvent("sh-burgershot:giveItem", function(item, cantidad)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    Player.Functions.AddItem(item, cantidad)
    TriggerClientEvent("inventory:client:ItemBox", src, QBCore.Shared.Items[item], "add")
end)

RegisterServerEvent("sh-burgershot:removeItem", function(item, cantidad)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    Player.Functions.RemoveItem(item, cantidad)
    TriggerClientEvent("inventory:client:ItemBox", src, QBCore.Shared.Items[item], "remove")
end)
---------------------------------------------------
-- 📦 Export público para manejar facturas por job
---------------------------------------------------
exports("HandleFacturaPago", function(targetSource, amount)
    local target = QBCore.Functions.GetPlayer(tonumber(targetSource))
    if not target then return false end

    local job = target.PlayerData.job
    if job and job.name == "burgershot" and job.onduty then
        exports['qb-banking']:AddMoney("burgershot", amount, "Pago de Factura")
        return true
    end

    return false
end)


-- =========================================================
-- Selección aleatoria de ruta con porcentajes
-- =========================================================
local function seleccionarRuta()
    local total = 0
    for _, ruta in ipairs(Config.Delivery.rutas) do
        total = total + ruta.porcentaje
    end
    local rand = math.random(total)
    local acum = 0
    for _, ruta in ipairs(Config.Delivery.rutas) do
        acum = acum + ruta.porcentaje
        if rand <= acum then
            return ruta
        end
    end
    return Config.Delivery.rutas[1] -- fallback
end

-- =========================================================
-- Iniciar pedido con cobro desde cuenta empresa
-- =========================================================
RegisterServerEvent("sh-burgershot:iniciarPedido", function(item, cantidad, precio)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or Player.PlayerData.job.name ~= Config.JobName or not Player.PlayerData.job.onduty then
        TriggerClientEvent("QBCore:Notify", src, "No tienes permisos para hacer pedidos", "error")
        return
    end

    local costeTotal = precio * cantidad
    local empresa = Config.JobName

    -- Verificar saldo de empresa
    local saldo = exports['qb-banking']:GetAccountBalance(empresa)
    if saldo < costeTotal then
        TriggerClientEvent('QBCore:Notify', src, "La empresa no tiene suficiente dinero", "error")
        return
    end

    -- Descontar de cuenta empresa
    exports['qb-banking']:RemoveMoney(empresa, costeTotal, "Pedido de materiales")

    -- Seleccionar ruta aleatoria
    local ruta = seleccionarRuta()

    -- Enviar datos al cliente
    TriggerClientEvent("sh-burgershot:comenzarDelivery", src, ruta, item, cantidad)

    TriggerClientEvent("QBCore:Notify", src, "Pedido iniciado, ve a recogerlo", "success")
end)

-- =========================================================
-- Entrega final del delivery (BURGERSHOT)
-- =========================================================
RegisterServerEvent("sh-burgershot:finalizarDelivery", function(item, cantidad)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    -- 🛒 Entregar ítem al jugador
    Player.Functions.AddItem(item, cantidad)
    TriggerClientEvent("inventory:client:ItemBox", src, QBCore.Shared.Items[item], "add")

    -- 💰 Calcular comisión en base a precio unitario y cantidad
    local precioUnitario = Config.Pedidos.items[item] and Config.Pedidos.items[item].precio or 0
    local valorTotal = precioUnitario * cantidad
    local comision = math.floor(valorTotal * 0.3) -- 30% de comisión

    -- 📥 Dar comisión al banco del jugador
    Player.Functions.AddMoney("bank", comision, "comision-delivery")

    -- ✅ Notificación
    TriggerClientEvent('QBCore:Notify', src,
        ("Entrega completada. Productos agregados al inventario. Comisión recibida: $%s"):format(comision),
        "success"
    )
end)

-- Registrar items como consumibles custom
local function registerCustomConsumable(itemName, data)
    QBCore.Functions.CreateUseableItem(itemName, function(source, item)
        local Player = QBCore.Functions.GetPlayer(source)
        if not Player then return end

        -- Quitar el ítem al usarlo
        if not exports['qb-inventory']:RemoveItem(source, item.name, 1, item.slot, 'sh-burgershot:consumable') then return end

        -- Enviar al cliente la animación y props
        TriggerClientEvent('sh-burgershot:client:useConsumable', source, itemName, data)
    end)
end

-- Eventos para sumar hambre/sed
RegisterNetEvent('sh-burgershot:server:addHunger', function(amount)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    local hunger = Player.PlayerData.metadata['hunger'] or 0
    local newHunger = math.min(hunger + amount, 100)

    Player.Functions.SetMetaData('hunger', newHunger)

    -- 🔹 Notificar al cliente para que actualice HUD
    TriggerClientEvent('hud:client:UpdateNeeds', src, newHunger, Player.PlayerData.metadata['thirst'] or 0)
end)

RegisterNetEvent('sh-burgershot:server:addThirst', function(amount)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    local thirst = Player.PlayerData.metadata['thirst'] or 0
    local newThirst = math.min(thirst + amount, 100)

    Player.Functions.SetMetaData('thirst', newThirst)

    -- 🔹 Notificar al cliente para que actualice HUD
    TriggerClientEvent('hud:client:UpdateNeeds', src, Player.PlayerData.metadata['hunger'] or 0, newThirst)
end)

-- Aquí defines todos tus ítems con sus datos
local consumables = {
    ['expr_frutilla'] = {
        progress = { label = 'Bebiendo Frutilla...', time = 4000 },
        animation = { animDict = 'mp_player_intdrink', anim = 'loop_bottle', flags = 49 },
        prop = { model = 'sf_p_sf_grass_gls_s_02a', bone = 60309, coords = vec3(0.0, 0.0, -0.08), rotation = vec3(0.0, 0.0, 0.0) },
        replenish = { type = 'Thirst', replenish = 35 }
    },
    ['expr_limon'] = {
        progress = { label = 'Bebiendo Limon...', time = 4000 },
        animation = { animDict = 'mp_player_intdrink', anim = 'loop_bottle', flags = 49 },
        prop = { model = 'p_w_grass_gls_s', bone = 60309, coords = vec3(0.0, 0.0, -0.08), rotation = vec3(0.0, 0.0, 0.0) },
        replenish = { type = 'Thirst', replenish = 35 }
    },
    ['refresco_bur'] = {
        progress = { label = 'Bebiendo Refresco...', time = 4000 },
        animation = { animDict = 'mp_player_intdrink', anim = 'loop_bottle', flags = 49 },
        prop = { model = 'prop_cs_bs_cup', bone = 60309, coords = vec3(0.0, 0.0, -0.005), rotation = vec3(0.0, 0.0, 0.0) },
        replenish = { type = 'Thirst', replenish = 35 }
    },
    ['agua_burger'] = {
        progress = { label = 'Bebiendo Agua...', time = 4000 },
        animation = { animDict = 'mp_player_intdrink', anim = 'loop_bottle', flags = 49 },
        prop = { model = 'prop_cs_paper_cup', bone = 60309, coords = vec3(0.0, 0.0, 0.03), rotation = vec3(0.0, 0.0, 0.0) },
        replenish = { type = 'Thirst', replenish = 35 }
    },
    ['hamb_doblecomp'] = {
        progress = { label = 'Comiendo Hamburguesa Doble...', time = 4000 },
        animation = { animDict = 'mp_player_inteat@burger', anim = 'mp_player_int_eat_burger', flags = 49 },
        prop = { model = 'prop_cs_burger_01', bone = 60309, coords = vec3(0.0, -0.01, 0.0), rotation = vec3(0.0, 0.0, 0.0) },
        replenish = { type = 'Hunger', replenish = 65 }
    },
    ['hamb_simple'] = {
        progress = { label = 'Comiendo Hamburguesa...', time = 4000 },
        animation = { animDict = 'mp_player_inteat@burger', anim = 'mp_player_int_eat_burger', flags = 49 },
        prop = { model = 'prop_cs_burger_01', bone = 60309, coords = vec3(0.0, -0.01, 0.0), rotation = vec3(0.0, 0.0, 0.0) },
        replenish = { type = 'Hunger', replenish = 50 }
    },
    ['burger_cafe'] = {
        progress = { label = 'Tomando Café...', time = 4000 },
        animation = { animDict = 'mp_player_intdrink', anim = 'loop_bottle', flags = 49 },
        prop = { model = 'prop_food_bs_coffee', bone = 60309, coords = vec3(0.03, 0.01, -0.04), rotation = vec3(0.0, 0.0, 0.0) },
        replenish = { type = 'Thirst', replenish = 25 }
    },
    ['papas_fr'] = {
        progress = { label = 'Comiendo Papas Fritas...', time = 4000 },
        animation = { animDict = 'mp_player_inteat@burger', anim = 'mp_player_int_eat_burger', flags = 49 },
        prop = { model = 'prop_food_bs_chips', bone = 60309, coords = vec3(0.0, 0.0, -0.08), rotation = vec3(180.0, 130.0, 60.0) },
        replenish = { type = 'Hunger', replenish = 30 }
    }
}

-- Registrar todos
for itemName, data in pairs(consumables) do
    registerCustomConsumable(itemName, data)
end

-- Comprar AguaShot
RegisterNetEvent("sh-burgershot:comprarAguaShot", function(cantidad)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local precio = Config.AguaShotPrice * cantidad

    if Player.Functions.RemoveMoney("bank", precio, "comprar-aguashot") then
        -- Sumar a la cuenta empresarial burgershot
        exports['qb-banking']:AddMoney("burgershot", precio, "Venta AguaShot")

        -- Dar el ítem al jugador
        Player.Functions.AddItem("agua_burger", cantidad)
        TriggerClientEvent('QBCore:Notify', src, "Compraste " .. cantidad .. " AguaShot(s)", "success")
    else
        TriggerClientEvent('QBCore:Notify', src, "No tenés suficiente dinero en el banco", "error")
    end
end)

-- Comprar CafeShot
-- Comprar CafeShot
RegisterNetEvent("sh-burgershot:comprarCafeShot", function(cantidad)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local p = Config.CafeteraEspresso
    if not p then
        print("[ERROR] Config.CafeteraEspresso no está definido en el server")
        return
    end

    local precio = p.precio * cantidad

    if Player.Functions.RemoveMoney("bank", precio, "comprar-cafeshot") then
        exports['qb-banking']:AddMoney("burgershot", precio, "Venta CafeShot")
        Player.Functions.AddItem(p.item, cantidad)
        TriggerClientEvent('QBCore:Notify', src, "Compraste " .. cantidad .. " " .. p.label .. "(s)", "success")
    else
        TriggerClientEvent('QBCore:Notify', src, "No tenés suficiente dinero en el banco", "error")
    end
end)

-- Obtener empleados en servicio
RegisterServerEvent("sh-burgershot:getOnlineStaff")
AddEventHandler("sh-burgershot:getOnlineStaff", function()
    local src = source
    local staff = {}
    for _, player in pairs(QBCore.Functions.GetPlayers()) do
        local Player = QBCore.Functions.GetPlayer(player)
        if Player and Player.PlayerData.job.name == "burgershot" and Player.PlayerData.job.onduty then
            table.insert(staff, {
                name = Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname,
                gradeLabel = Player.PlayerData.job.grade.name
            })
        end
    end
    TriggerClientEvent("sh-burgershot:client:mostrarStaff", src, staff)
end)

-- Contratar empleado
RegisterServerEvent("sh-burgershot:contratarEmpleado", function(targetId)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local Target = QBCore.Functions.GetPlayer(tonumber(targetId))

    if not Player or not Target then return end
    if Player.PlayerData.job.name ~= "burgershot" then return end

    Target.Functions.SetJob("burgershot", 0)

    exports.oxmysql:update('UPDATE players SET job = ? WHERE citizenid = ?', {
        json.encode({ name = "burgershot", label = "Vespucci BurgerShot", grade = { name = "Empleado", level = 0 } }),
        Target.PlayerData.citizenid
    })

    TriggerClientEvent("QBCore:Notify", src, "Contrataste a " .. Target.PlayerData.charinfo.firstname, "success")
    TriggerClientEvent("QBCore:Notify", targetId, "Fuiste contratado en el Burgershot", "success")
end)

-- Obtener empleados
QBCore.Functions.CreateCallback("sh-burgershot:getEmpleados", function(source, cb)
    exports.oxmysql:query('SELECT citizenid, charinfo, job FROM players WHERE JSON_EXTRACT(job, "$.name") = ?', { "burgershot" }, function(result)
        local empleados = {}
        for _, v in pairs(result) do
            local jobData = json.decode(v.job)
            local charinfo = json.decode(v.charinfo)
            local fullName = charinfo.firstname .. " " .. charinfo.lastname

            table.insert(empleados, { name = fullName, grade = jobData.grade.level, citizenid = v.citizenid })
        end
        cb(empleados)
    end)
end)

-- Despedir empleado
RegisterServerEvent("sh-burgershot:despedirEmpleado", function(citizenid)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or Player.PlayerData.job.name ~= "burgershot" then return end

    exports.oxmysql:update('UPDATE players SET job = ? WHERE citizenid = ?', {
        json.encode({ name = "unemployed", label = "Unemployed", grade = { name = "unemployed", level = 0 } }),
        citizenid
    }, function(rowsChanged)
        if rowsChanged > 0 then
            for _, id in pairs(QBCore.Functions.GetPlayers()) do
                local Target = QBCore.Functions.GetPlayer(id)
                if Target and Target.PlayerData.citizenid == citizenid then
                    Target.Functions.SetJob("unemployed", 0)
                    TriggerClientEvent("QBCore:Notify", Target.PlayerData.source, "Fuiste despedido del Burgershot", "error")
                end
            end
            TriggerClientEvent("QBCore:Notify", src, "Empleado despedido exitosamente", "success")
        else
            TriggerClientEvent("QBCore:Notify", src, "No se pudo despedir al empleado", "error")
        end
    end)
end)

-- Obtener empleados online para rangos
RegisterNetEvent("sh-burgershot:getEmpleadosOnlineParaRangos", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or Player.PlayerData.job.name ~= "burgershot" or Player.PlayerData.job.grade.level < 1 then return end

    local lista = {}
    for _, id in pairs(QBCore.Functions.GetPlayers()) do
        local Target = QBCore.Functions.GetPlayer(id)
        if Target and Target.PlayerData.job.name == "burgershot" then
            table.insert(lista, {
                name = Target.PlayerData.charinfo.firstname .. " " .. Target.PlayerData.charinfo.lastname,
                grade = Target.PlayerData.job.grade.level,
                id = Target.PlayerData.source
            })
        end
    end

    TriggerClientEvent("sh-burgershot:mostrarRangosMenu", src, lista)
end)

-- Cambiar rango
RegisterServerEvent("sh-burgershot:setNuevoRango", function(data)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local Target = QBCore.Functions.GetPlayer(tonumber(data.id))
    if not Player or not Target then return end
    if Player.PlayerData.job.name ~= "burgershot" or Player.PlayerData.job.grade.level < 1 then return end

    Target.Functions.SetJob("burgershot", data.rango)

    exports.oxmysql:update('UPDATE players SET job = ? WHERE citizenid = ?', {
        json.encode({ name = "burgershot", label = "Vespucci BurgerShot", grade = { name = "manual", level = data.rango } }),
        Target.PlayerData.citizenid
    })

    TriggerClientEvent("QBCore:Notify", src, "Nuevo rango asignado a " .. Target.PlayerData.charinfo.firstname, "success")
    TriggerClientEvent("QBCore:Notify", data.id, "Tu rango ha sido cambiado", "success")
end)

-- Obtener empleados en servicio para dar bono
RegisterServerEvent("sh-burgershot:getOnlineStaffForBonus")
AddEventHandler("sh-burgershot:getOnlineStaffForBonus", function()
    local src = source
    local staff = {}
    for _, player in pairs(QBCore.Functions.GetPlayers()) do
        local Player = QBCore.Functions.GetPlayer(player)
        if Player and Player.PlayerData.job.name == "burgershot" and Player.PlayerData.job.onduty then
            table.insert(staff, {
                source = Player.PlayerData.source,
                name = Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname,
                gradeLabel = Player.PlayerData.job.grade.name
            })
        end
    end
    TriggerClientEvent("sh-burgershot:client:bonoElegir", src, staff)
end)

-- Enviar bono
RegisterServerEvent("sh-burgershot:enviarBono", function(targetSrc, amount)
    local src = source
    local sender = QBCore.Functions.GetPlayer(src)
    local receiver = QBCore.Functions.GetPlayer(tonumber(targetSrc))
    if not sender or not receiver then return end

    amount = tonumber(amount)
    if not amount or amount <= 0 then return end

    local balance = exports['qb-banking']:GetAccountBalance("burgershot")
    if balance < amount then
        TriggerClientEvent('QBCore:Notify', src, "Fondos insuficientes en la cuenta del Burgershot.", "error")
        return
    end

    exports['qb-banking']:RemoveMoney("burgershot", amount, "Bono para empleado")
    receiver.Functions.AddMoney("bank", amount, "bono-burgershot")

    -- Si tienes un sistema de historial de movimientos
    if registrarMovimiento then
        registrarMovimiento(sender.PlayerData.citizenid, receiver.PlayerData.citizenid, 'darbono', amount)
    end

    TriggerClientEvent('QBCore:Notify', src, "Bono enviado exitosamente.", "success")
    TriggerClientEvent('QBCore:Notify', receiver.PlayerData.source, "Recibiste un bono de $" .. amount, "success")
end)

-- 📦 Construir menú de totales de pedidos
local function buildPedidosTotalesMenu(data)
    local menu = {
        { header = "📦 Totales de Pedidos", isMenuHeader = true }
    }

    for _, pedido in ipairs(data) do
        local nombre = pedido.nombre or "Desconocido"
        local total_pedidos = pedido.total_pedidos or 0
        local total_cantidad = pedido.total_cantidad or 0

        table.insert(menu, {
            header = string.format("%s - Pedidos: %d - Unidades: %d", nombre, total_pedidos, total_cantidad)
        })
    end

    table.insert(menu, {
        header = "⬅️ Volver",
        params = { event = "sh-burgershot:menuPedidos" }
    })

    return menu
end

-- 📦 Evento para mostrar pedidos totales agrupados
RegisterNetEvent("sh-burgershot:mostrarTotalesPedidos")
AddEventHandler("sh-burgershot:mostrarTotalesPedidos", function()
    local src = source
    exports.oxmysql:query([[
        SELECT 
            CONCAT(JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.firstname')), ' ', JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.lastname'))) AS nombre,
            COUNT(*) AS total_pedidos,
            SUM(b.amount) AS total_cantidad
        FROM burgershot_pedidos b
        INNER JOIN players p ON p.citizenid = b.citizenid
        GROUP BY nombre
        ORDER BY total_cantidad DESC
        LIMIT 30
    ]], {}, function(result)
        if result and #result > 0 then
            TriggerClientEvent("qb-menu:client:openMenu", src, buildPedidosTotalesMenu(result))
        else
            TriggerClientEvent("qb-menu:client:openMenu", src, {
                { header = "📦 Totales de Pedidos", isMenuHeader = true },
                { header = "No hay pedidos realizados aún", txt = "Esperá a que se hagan algunos pedidos." },
                { header = "⬅️ Volver", params = { event = "sh-burgershot:menuPedidos" } }
            })
        end
    end)
end)

-- 📦 Guardar pedido al finalizar delivery
RegisterNetEvent("sh-burgershot:finalizarDelivery", function(item, cantidad)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local citizenid = Player.PlayerData.citizenid

    exports.oxmysql:insert('INSERT INTO burgershot_pedidos (citizenid, item, amount) VALUES (?, ?, ?)', {
        citizenid,
        item,
        cantidad
    })

    -- Notificación opcional
    TriggerClientEvent("QBCore:Notify", src, "Pedido registrado exitosamente", "success")
end)

RegisterServerEvent("sh-burgershot:enviarAnuncio", function(mensaje)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    if not Player then return end

    if Player.PlayerData.job.name ~= "burgershot" or not Player.PlayerData.job.onduty then
        TriggerClientEvent("QBCore:Notify", src, "No estás autorizado o no estás en servicio", "error")
        return
    end

    local ahora = os.time()
    if ahora - ultimoAnuncio < tiempoEspera then
        local faltan = tiempoEspera - (ahora - ultimoAnuncio)
        local minutos = math.floor(faltan / 60)
        local segundos = faltan % 60
        TriggerClientEvent("QBCore:Notify", src, ("Debes esperar %02d:%02d minutos para enviar otro anuncio."):format(minutos, segundos), "error")
        return
    end

    -- Enviar anuncio a todos los jugadores
    TriggerClientEvent("sh-burgershot:mostrarAnuncio", -1, mensaje)
    ultimoAnuncio = ahora
end)

-- 📜 Obtener movimientos
-- 📜 Obtener movimientos
RegisterServerEvent("sh-burgershot:getMovimientos")
AddEventHandler("sh-burgershot:getMovimientos", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    exports.oxmysql:execute('SELECT * FROM burgershot_movimientos ORDER BY fecha DESC LIMIT 50', {}, function(result)
        local movimientos = {}

        for _, v in ipairs(result) do
            -- Usar siempre el nombre guardado en DB
            local actorName = v.actorname or v.citizenid

            table.insert(movimientos, {
                tipo = v.tipo,
                cantidad = v.cantidad,
                actorName = actorName
            })
        end

        TriggerClientEvent("sh-burgershot:client:mostrarMovimientos", src, movimientos)
    end)
end)

-- 💰 Ver cuenta
RegisterServerEvent("sh-burgershot:getCuentaEmpresa")
AddEventHandler("sh-burgershot:getCuentaEmpresa", function()
    local src = source
    local balance = exports['qb-banking']:GetAccountBalance("burgershot")
    TriggerClientEvent("sh-burgershot:client:mostrarCuenta", src, balance or 0)
end)

-- 📥 Depositar
RegisterServerEvent("sh-burgershot:depositarEmpresa", function(cantidad)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    if Player.PlayerData.job.name ~= "burgershot" or Player.PlayerData.job.grade.level < 2 then return end
    cantidad = tonumber(cantidad)
    if not cantidad or cantidad <= 0 then return end

    if Player.Functions.RemoveMoney("bank", cantidad) then
        exports['qb-banking']:AddMoney("burgershot", cantidad, "Depósito a la empresa")
        registrarMovimiento(Player.PlayerData.citizenid, nil, 'depositar', cantidad)
        TriggerClientEvent("QBCore:Notify", src, "Ingresaste $" .. cantidad .. " a la cuenta del negocio", "success")
    else
        TriggerClientEvent("QBCore:Notify", src, "No tienes suficiente dinero", "error")
    end
end)

-- 💸 Retirar
RegisterServerEvent("sh-burgershot:retirarEmpresa", function(cantidad)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    if Player.PlayerData.job.name ~= "burgershot" or Player.PlayerData.job.grade.level < 2 then return end
    cantidad = tonumber(cantidad)
    if not cantidad or cantidad <= 0 then return end

    local balance = exports['qb-banking']:GetAccountBalance("burgershot")
    if balance < cantidad then
        TriggerClientEvent("QBCore:Notify", src, "Fondos insuficientes en la cuenta del negocio.", "error")
        return
    end

    exports['qb-banking']:RemoveMoney("burgershot", cantidad, "Retiro personal de jefe")
    Player.Functions.AddMoney("bank", cantidad, "retiro-burgershot")
    registrarMovimiento(Player.PlayerData.citizenid, nil, 'retirar', cantidad)
    TriggerClientEvent("QBCore:Notify", src, "Retiraste $" .. cantidad .. " de la cuenta del negocio a tu cuenta bancaria.", "success")
end)

-- 📢 Enviar alerta de pánico a policías en servicio
RegisterServerEvent("sh-burgershot:enviarAlertaPanico", function(coords)
    local src = source
    local players = QBCore.Functions.GetPlayers()

    for _, playerId in pairs(players) do
        local player = QBCore.Functions.GetPlayer(playerId)
        if player and player.PlayerData.job.name == "police" and player.PlayerData.job.onduty then
            TriggerClientEvent("sh-burgershot:mostrarAlertaPanico", playerId, coords)
        end
    end
end)

-- Guardar estado de jugadores y frecuencias
local usuariosRadio = {}

-- Comprobar si el jugador tiene una radio
QBCore.Functions.CreateCallback("sh-burgershot:checkRadioItem", function(source, cb)
    local Player = QBCore.Functions.GetPlayer(source)
    if Player and Player.Functions.GetItemByName("radio") then
        cb(true)
    else
        cb(false)
    end
end)

-- Cuando un jugador selecciona una frecuencia
RegisterNetEvent("sh-burgershot:cambiarFrecuencia", function(freq)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local nombre = Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname
    usuariosRadio[src] = {
        -- id = src,  -- <-- sacalo de acá para no enviarlo
        nombre = nombre,
        frecuencia = freq
    }

    actualizarUsuarios()
end)

-- Cuando un jugador solicita la lista de usuarios
RegisterNetEvent("sh-burgershot:solicitarUsuariosRadio", function()
    local src = source
    TriggerClientEvent("sh-burgershot:enviarUsuariosRadio", src, usuariosRadio)
end)

-- Cuando un jugador se desconecta, quitarlo de la lista
AddEventHandler("playerDropped", function()
    local src = source
    usuariosRadio[src] = nil
    actualizarUsuarios()
end)

-- Función para enviar la lista a todos
function actualizarUsuarios()
    TriggerClientEvent("sh-burgershot:enviarUsuariosRadio", -1, usuariosRadio)
end

-- Cuando un jugador cierra la radio manualmente
RegisterNetEvent("sh-burgershot:cerrarRadio", function()
    local src = source
    if usuariosRadio[src] then
        usuariosRadio[src] = nil
        actualizarUsuarios()
    end
end)

-- Abrir stash temporal
RegisterNetEvent("sh-burgershot:abrirStashTemporal", function(stashName)
    local src = source
    exports['qb-inventory']:OpenInventory(src, stashName, {
        label = "Pedido Temporal",
        maxweight = 30000,
        slots = 7
    })
end)

RegisterNetEvent("sh-burgershot:checkCooldownLimpieza", function()
    local src = source
    local now = os.time()

    if not jugadoresLimpiando[src] then
        jugadoresLimpiando[src] = { zonasCompletas = 0 }
    end

    -- Cooldown global (opcional, puedes hacerlo por jugador)
    if jugadoresLimpiando.cooldown and now - jugadoresLimpiando.cooldown < Config.LimpiezaBurger.cooldown then
        local minutos = math.ceil((Config.LimpiezaBurger.cooldown - (now - jugadoresLimpiando.cooldown)) / 60)
        TriggerClientEvent("QBCore:Notify", src, "Debes esperar " .. minutos .. " minutos para volver a limpiar.", "error")
        return
    end

    jugadoresLimpiando[src].zonasCompletas = 0
    jugadoresLimpiando.cooldown = now
    TriggerClientEvent("sh-burgershot:cooldownOK", src)
end)

RegisterNetEvent("sh-burgershot:zonaCompletada", function()
    local src = source
    if jugadoresLimpiando[src] then
        jugadoresLimpiando[src].zonasCompletas = (jugadoresLimpiando[src].zonasCompletas or 0) + 1
    end
end)

-- Pagar limpieza al jugador
RegisterNetEvent("sh-burgershot:pagarLimpieza", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    Player.Functions.AddMoney("bank", Config.LimpiezaBurger.pagoTotal, "pago-limpieza-burgershot")
    TriggerClientEvent("QBCore:Notify", src, "Has limpiado todo el Burgershot. Buen trabajo! Has recibido $" .. Config.LimpiezaBurger.pagoTotal, "success")
end)

-- Limpieza del estado al salir
AddEventHandler("playerDropped", function()
    local src = source
    jugadoresLimpiando[src] = nil
end)
