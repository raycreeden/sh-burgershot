window.addEventListener('message', function(event) {
    if(event.data.action == "mostrarAnuncio"){
        let anuncio = document.getElementById('anuncio');
        anuncio.innerText = event.data.texto;
        anuncio.style.display = 'block';
    }
    if(event.data.action == "ocultarAnuncio"){
        document.getElementById('anuncio').style.display = 'none';
    }
});

// ===== RADIO BURGERSHOT =====
window.addEventListener('message', function(event) {
    if (event.data.action === "abrirRadio") {
    const panel = document.getElementById('radio-panel');
    panel.classList.remove('hidden'); // quitar hidden
    panel.style.display = 'block';
}

if (event.data.action === "cerrarRadio") {
    const panel = document.getElementById('radio-panel');
    panel.style.display = 'none';
    panel.classList.add('hidden');
}

if (event.data.action === "actualizarUsuarios") {
    const usuarios = Array.isArray(event.data.usuarios)
        ? event.data.usuarios
        : Object.values(event.data.usuarios || {}); // convertir objeto a array
    actualizarListaUsuarios(usuarios, usuarios.length);
}
});

function seleccionarFrecuencia(freq) {
    fetch(`https://${GetParentResourceName()}/seleccionarFrecuencia`, {
        method: 'POST',
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ frecuencia: freq })
    });
}

function cerrarRadio() {
    fetch(`https://${GetParentResourceName()}/cerrarRadio`, {
        method: 'POST',
        headers: { "Content-Type": "application/json" }
    }).finally(() => {
        document.getElementById('radio-panel').style.display = 'none';
        document.body.focus();
    });
}

function actualizarListaUsuarios(usuarios, total) {
    const lista = document.getElementById('lista-usuarios');
    lista.innerHTML = "";

    // Mostrar contador
    const contador = document.getElementById('contador-usuarios');
    if (contador) {
        contador.innerText = `Conectados: ${total}`;
    }

  usuarios.forEach(u => {
  if (u && u.nombre) {  // verifico que 'u' no sea null y tenga 'nombre'
    const li = document.createElement('li');
    li.innerText = `${u.nombre} - ${u.frecuencia}`;
    lista.appendChild(li);
  }
});
}

// ===== Botón cerrar =====
document.getElementById("radio-cerrar")?.addEventListener("click", function() {
    cerrarRadio();
});

// ===== Tecla Escape =====
document.addEventListener("keydown", function(e) {
    if (e.key === "Escape") {
        cerrarRadio();
    }
});

// ===== Botones de frecuencia =====
document.querySelectorAll("#radio-panel .frecuencias button").forEach(btn => {
    btn.addEventListener("click", function() {
        const freq = this.getAttribute("data-freq");
        if (freq) {
            seleccionarFrecuencia(freq);
        }
    });
});

document.querySelectorAll('.freq-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const lista = btn.parentElement.querySelector('.usuarios-list');
        lista.style.display = lista.style.display === 'block' ? 'none' : 'block';
    });
});

document.getElementById("desconectar-radio")?.addEventListener("click", function() {
    fetch(`https://${GetParentResourceName()}/desconectarFrecuencia`, {
        method: 'POST',
        headers: { "Content-Type": "application/json" }
    });
});
 
const SOUND_MAP = {
    cortar: new Howl({ src: ['sounds/cortar.ogg'] }),
    freir: new Howl({ src: ['sounds/freir.ogg'] }),
    exprimidor: new Howl({ src: ['sounds/exprimidor.ogg'] })
};

window.addEventListener('message', (event) => {
    if (event.data.action === 'playSound' && SOUND_MAP[event.data.file]) {
        const sound = SOUND_MAP[event.data.file];
        sound.play();

        // Detener el sonido a los 4 segundos
        setTimeout(() => {
            sound.stop();
        }, 4500);
    }
});
