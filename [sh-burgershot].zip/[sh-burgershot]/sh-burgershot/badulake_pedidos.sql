CREATE TABLE IF NOT EXISTS `burgershot_pedidos` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `citizenid` VARCHAR(50) NOT NULL,
    `item` VARCHAR(50) NOT NULL,
    `amount` INT NOT NULL,
    `timestamp` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS `burgershot_movimientos` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `citizenid` VARCHAR(50) NOT NULL,
    `actorname` VARCHAR(100) DEFAULT NULL,
    `targetid` VARCHAR(50),
    `tipo` VARCHAR(50) NOT NULL,
    `cantidad` INT NOT NULL,
    `fecha` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);