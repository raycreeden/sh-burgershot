fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'TuNombre'
description 'Burgershot Job Script'
version '1.0.0'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'

dependencies {
    'qb-core',
    'qb-target',
    'qb-inventory'
}

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/sounds/cortar.ogg',
    'html/sounds/freir.ogg',
    'html/sounds/exprimidor.ogg',
}
ui_page 'html/index.html'